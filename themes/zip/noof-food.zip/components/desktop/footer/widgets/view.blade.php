        
        <!-- footer area start -->
        <footer class="padding-tb" style="background-image: url({{$data->background(desktop_asset('css/bg-image/footer-bg.jpg'))}});">
            <div class="container">
                <div class="row justify-content-center">
                    {!! $html->desktop_footer_widgets->components !!}

                </div>
            </div>
        </footer>
        <!-- footer area ends -->