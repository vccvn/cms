<div class="widget widget-search">
    <form action="{{route('client.search')}}" method="get">
        <div class="search-wrapper">
            <input type="text" name="s" placeholder="Tìm kiếm...">
            <button type="submit"><i class="icofont-search-2"></i></button>
        </div>
    </form>
</div>
