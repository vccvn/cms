
                        <div class="item">
                            <div class="service-block">
                                <span><i class="{{$data->icon}}"></i></span>
                                <h4>{{$data->title}}</h4>
                                <p>L{{$data->description}}</p>
                            </div><!-- end service-block -->
                        </div><!-- end item -->