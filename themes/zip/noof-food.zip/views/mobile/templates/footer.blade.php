@php
    $styles = [
        1 => 'section-padding',
        2 => 'section-padding',
        3 => 'pd-t-b-30'
    ];
    $class = $styles[$footer->style]??$styles[1];
@endphp
            <!--=============== FOOTER ===============-->
            <section id="footer" class="{{$class}}"> 
                <div class="container-fluid text-center">
                    {!! $html->mobile_footer->components !!}
                </div><!-- end container-fluid -->
            </section><!-- end footer -->
