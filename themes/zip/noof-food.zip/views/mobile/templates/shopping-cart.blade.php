        
        
        <!--================ SHOPPING-CART ==============-->
        <div id="shopping-cart-sidebar" class="shc-sidebar">
            <ul class="list-unstyled cart-list {{parse_classname('cart-items')}}">

            </ul>
            
            <div class="cart-info text-right">
                <h4>Số SP : <span class="{{parse_classname('cart-quantity')}}">0</span></h4>
                <h4>Tạm tính: <span class="{{parse_classname('cart-sub-total-ammount')}}">0</span></h4>
                <a href="{{route('client.orders.cart')}}" class="btn btn-black">Giỏ hàng</a>
                <a href="{{route("client.orders.checkout")}}" class="btn btn-primary">Thanh toán</a>
            </div><!-- end cart-info -->
        </div><!-- shopping-cart-sidebar -->
            