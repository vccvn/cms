
        
        <!--============== USER-PROFILE-SIDEBAR =============-->
        <div id="user-profile-sidebar" class="user-prf-sidebar">
        	<div class="user-prf-sidebar-img text-center" style="background:url('{{mobile_asset('images/usr-prf-back-restaurant.jpg')}}'); background-size:cover;">
    			<div class="overlay">
                    
                </div><!-- end overlay -->
        	</div><!-- end user-prf-sidebar-img -->
            
            <div class="user-prf-sidebar-links">
            	<ul class="list-unstyled">
                	<li><a href="user-profile.html"><span><i class="fa fa-user"></i></span>My Profile</a></li>
                    <li><a href="edit-profile.html"><span><i class="fa fa-pencil-alt"></i></span>Edit Profile</a></li>
                    <li><a href="forget-password-1.html"><span><i class="fa fa-question"></i></span>Forget Password</a></li>
                    <li><a href="reset-password.html"><span><i class="fa fa-sync"></i></span>Reset Password</a></li>
                    <li><a href="#"><span><i class="fa fa-sign-out-alt"></i></span>Sign Out</a></li>
                </ul>
            </div><!-- end user-prf-sidebar-links -->
        </div><!-- end user-profile-sidebar -->
        
        
