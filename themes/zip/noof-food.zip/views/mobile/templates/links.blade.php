
    <!-- Google Fonts -->	
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300italic,800italic,800,700italic,700,600italic,600,400italic,300%7CRoboto+Condensed:400,400i,700,700i%7CGreat+Vibes" rel="stylesheet"> 
    
    <!-- Bootstrap Stylesheet -->	
    <link rel="stylesheet" href="{{mobile_asset('css/bootstrap-4.4.1.min.css')}}">
    
    <!-- Font Awesome Stylesheet -->
    <link rel="stylesheet" href="{{mobile_asset('css/fontawesome-all.min.css')}}">
        
    <!-- Custom Stylesheets -->	
    <link rel="stylesheet" href="{{mobile_asset('css/style.css')}}">

    @if ($color = $general->color('orange'))
        <link rel="stylesheet" href="{{mobile_asset('css/colors/'.$color.'.css')}}">    
    @else
        <link rel="stylesheet" href="{{mobile_asset('css/colors/orange.css')}}">
    @endif
    
    
    <!-- Flex Slider Stylesheets -->	
    <link rel="stylesheet" href="{{mobile_asset('css/flexslider.css')}}">
    
    <!-- OWL Stylesheets -->	
    <link rel="stylesheet" href="{{mobile_asset('css/owl.carousel.css')}}">
    <link rel="stylesheet" href="{{mobile_asset('css/owl.theme.css')}}">
        
    
    <!-- Favicons -->
    @if ($shortcut_icon = $siteinfo->favicon($__env->yieldContent('favicon', mobile_asset('images/favicon.png'))))
        <link rel="shortcut icon" type="image/png" href="{{$shortcut_icon}}">
    @endif
    
    @if ($apple_icon = $siteinfo->apple_touch_icon($__env->yieldContent('apple-touch-icon')))
        <link rel="apple-touch-icon" href="{{$apple_icon}}">
    @endif
    