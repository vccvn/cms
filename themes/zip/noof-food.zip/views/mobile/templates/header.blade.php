
            
            <!--========= HEADER =========-->
            <div class="header">
                <div class="fixed-header">
                    <div class="container-fluid">
                        <div class="header-links left">
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item"><a href="javascript:void(0)" id="sidenav-open"><span><i class="fa fa-bars"></i></span></a></li>
                            </ul>
                        </div><!-- end header-links -->
                        <div class="header-logo">
                            <a href="{{route('home')}}">
                                @if ($general->logo_type == 'image' && ($logo = $general->logo?$general->logo:($siteinfo->mobile_logo?$siteinfo->mobile_logo:$siteinfo->logo)))
                                
                                    <img src="{{$logo}}" alt="{{$siteinfo->site_name}}">
                                
                                @else
                                    <h4>
                                        @if ($general->logo_icon)
                                        <span><i class="{{$general->logo_icon}}"></i></span>
                                        @endif
                                        {!!$general->logo_text($siteinfo->site_name)!!}
                                    </h4>
                                @endif
                            </a>
                        </div><!-- end header-logo -->
                        
                        <div class="header-links">
                            <ul class="list-unstyled list-inline">
                            	
                                <li class="list-inline-item shopping-cart"><a href="javascript:void(0)" id="shc-side-open"><span><i class="fa fa-shopping-cart"></i></span><span class="cart-badge {{parse_classname('cart-quantity')}}">0</span></a></li>
                                <li class="list-inline-item user-link"><a href="javascript:void(0)" id="usr-side-open"><span><i class="fa fa-user"></i></span></a></li>
                                
                            </ul>
                        </div><!-- end header-links -->
                    </div><!-- end container-fluid -->
                </div><!-- end fixed-header -->
            </div><!-- end header -->
            