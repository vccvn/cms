@php
$socials = $options->theme->socials;
$list = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin'];


@endphp
        <!--============ SIDE-NAV =============-->
        <div class="sidenav-content">
            <div id="mySidenav" class="sidenav">
                <div id="web-name">
                    @if ($general->logo_type == 'image' && ($logo = $general->logo?$general->logo:($siteinfo->mobile_logo?$siteinfo->mobile_logo:$siteinfo->logo)))
                        <div class="site-logo">
                            <a href="{{route('home')}}">
                                <img src="{{$logo}}" alt="{{$siteinfo->site_name}}">
                            </a>
                        </div>
                    @else
                    <h2>
                        @if ($general->logo_icon)
                        <span><i class="{{$general->logo_icon}}"></i></span> <br/>    
                        @endif
                        {!!$general->logo_text($siteinfo->site_name)!!}
                    </h2>
                    @endif
                    
                    <ul class="main-menu-social list-inline list-unstyled text-center">
                        @foreach ($list as $item)
                            @if ($link = $socials->get($item))
                            <li class="list-inline-item"><a href="{{$link}}"><span><i class="fab fa-{{$item.($item == 'facebook'?'-f':'')}}"></i></span></a></li>
                            @endif
                        @endforeach
                        
                    </ul>  
                </div><!-- end web-name -->

                <div id="main-menu">
                    <div class="sidenav-closebtn">
                        <button class="btn btn-default" id="sidenav-close">&times;</button>
                    </div><!-- end sidenav-closebtn -->
                    @php
                        $sidenav = $helper->getCustomMenu($general->sidebar_menu_id, 4);
                        
                        $sidenav->addAction(function($item, $link){
                            $itemId = 'menu-item-'.$item->level . '-' . $item->index();
                            $item->tagName = null;
                            $link->addClass('list-group-item');
                            $isActive = $item->isActive();
                            if($isActive){
                                $link->addClass('active');
                            }
                            if($item->hasSubMenu()){
                                $link->text->tagName = null;
                                $link->append('<span><i class="fa fa-caret-down arrow"></i></span>');
                                if($icon = $link->getIcon('icon')){
                                    $icon->before('<span>')->after('</span>');
                                }
                                $link->attr('data-toggle', "collapse");
                                $item->sub->addClass('collapse sub-menu');
                                $item->sub->attr('data-parent',"#main-menu");
                                $link->href = '#' . $itemId;
                                $item->sub->id = $itemId;
                                $item->sub->tagName = 'div';
                            }
                        });
                        $sidenav->addClass('list-group');
                    @endphp
                    {!! $sidenav !!}
                    
                    <!-- end list-group -->
                </div><!-- end main-menu -->
            </div><!-- end mySidenav -->
        </div><!-- end sidenav-content -->


        
        <!--=============== FULLSCR-NAV ==============-->
        <div id="fullscr-nav" class="fullscr-navigation">
            <button id="fullscr-close"><span><i class="fa fa-times"></i></span></button>
            @php
                $menu = $helper->getCustomMenu($general->full_screen_menu_id, 1, [], [
                    'props' => [
                        'menu_class' => '',
                        'item_class' => '',
                        'link_class' => '',
                        'icon_prefix_class' => 'fullscr-nav-icon '
                    ]
                ]);
                $menu->addAction(function($item, $link){
                    if($icon = $link->getIcon('icon')){
                        $icon->before('<span>')->after('</span>');
                    }
                    $item->append('<span class="border-shape"></span>');
                })->addClass('list-unstyled');
            @endphp
            {!! $menu !!}
        </div><!-- end fullscr-nav -->
            
            