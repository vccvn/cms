
    <!-- Page Scripts Starts -->
    <script src="{{mobile_asset('js/jquery.min.js')}}"></script>
    <script src="{{mobile_asset('js/popper.min.js')}}"></script>
    <script src="{{mobile_asset('js/bootstrap-4.4.1.min.js')}}"></script>
    <script src="{{mobile_asset('js/jquery.flexslider.js')}}"></script>
    <script src="{{mobile_asset('js/owl.carousel.min.js')}}"></script>
    <script src="{{mobile_asset('js/custom-navigation.js')}}"></script>
    <script src="{{mobile_asset('js/custom-flex.js')}}"></script>
    <script src="{{mobile_asset('js/custom-owl.js')}}"></script>
    <!-- Page Scripts Ends -->
    <script>
        window.customCartInit = function () {
            App.cart.init({
                decimal: 0,
                templates: {
                    item: '' +
                        '<li data-item-id="{$id}">'+
                            '<div class="cart-item">' +
                                '<div class="item-img">' +
                                    '<a href="{$link}"><img src="{$image}" class="img-fluid" alt="{$name}" /></a>' +
                                '</div>' +
                                '<div class="item-text dish-list-text info">'+
                                    '<h4><a href="{$link}">{$name}</a></h4>' +
                                    '<h5>Đơn giá: {$price}</h5>'+
                                    '{$attributes}'+
                                    '<h5>Số lượng: <input type="number" class="form-control {{parse_classname('cart-item-quantity')}}" min="1" value="{$quantity}" data-item-id="{$id}"></h5>'+
                                '</div>' +
                                '<div class="attr-qty">'+
                                   
                                '</div>' +
                                '<h4 class="total">Thành tiền: <span>{$total_price}</span></h4>' +
                                '<div class="item-close">' +
                                    '<button class="btn {{parse_classname('remove-cart-item')}}" data-item-id="{$id}"><span><i class="fa fa-times-circle"></i></span></button>' +
                                '</div>' +
                            '</div>' +
                        '</li>',
                   
                    attribute: '<p><strong class="{{parse_classname('attribute-label')}}">{$label}</strong>: <span class="{{parse_classname('attribute-value')}}">{$value}</span></p>'
                }
            });
        };
        window.authInit = function(){
            

            App.auth.init({
                urls: {
                    check: "{{route('client.account.check')}}"
                },
                templates: {
                    account_section: "<i class=\"fa fa-user\"></i> {$name}",
                    link: "<a class=\"dropdown-item\" href=\"{$link}\">{$text}</a>"
                }
            });
            App.auth.check(function(res){
                var $userPanel = $('#user-profile-sidebar');
                if(!$userPanel.length) return false;
                var user = res.data;
                $links = $userPanel.find('.user-prf-sidebar-links ul');
                var link = '<li><a href="{$link}"><span><i class="fa fa-{$icon}"></i></span>{$text}</a></li>';
                var icons = {
                    account: 'user',
                    admin: 'cogs',
                    orders: 'cart-plus',
                    logout: 'sign-out-alt',
                    login: 'user-lock',
                    register: 'user-edit'
                };
                var links = '';
                if(res.status){
                    var $info = $userPanel.find('.overlay');
                    var tpl = '<img src="{$avatar}" class="img-fluid rounded-circle" alt="user-profile" />'
                        +'<h3>-- {$name} --</h3>';
                    if($info.length){
                        $info.html(App.str.eval(tpl, user));
                    }
                }
                if(user.links && App.isObject(user.links)){
                    for (const k in user.links) {
                        if (user.links.hasOwnProperty(k)) {
                            var d = user.links[k];
                            d.icon = typeof icons[k] != "undefined" ? icons[k] : 'link';
                            links += App.str.eval(link, d);
                        }
                    }
                    $links.html(links);
                }
                    
            });
            

        };
    </script>
    @include($_lib.'js')

        
    
        

