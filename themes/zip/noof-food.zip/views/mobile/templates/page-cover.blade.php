
@php
$icon = $__env->yieldContent('page_icon', isset($page_icon)?$page_icon:'fa fa-star');
@endphp
        
            <!--========= PAGE-COVER =========-->
            <div class="page-cover">
                <div class="container-fluid">
                    <h3>
                        <span class="cover-left-icon float-left">
                            @if ($icon)
                                <i class="{{$icon}}"></i>
                            @endif
                        </span>
                        @yield('cover_title', isset($cover_title)?$cover_title:'')
                        <span class="cover-right-icon float-right">
                            @if ($icon)
                                <i class="{{$icon}}"></i>
                            @endif
                        </span>
                    </h3>
                </div><!-- end container-fluid -->
            </div><!-- end page-cover -->
            