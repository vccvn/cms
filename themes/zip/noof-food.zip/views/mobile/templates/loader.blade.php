@if ($general->show_loader)

    <!--====== LOADER =====-->
    <div class="loader"></div>

    
@endif