@php
    $pageOptions = $options->theme->pages->makeByPrefix('mobile_');
    $pageHeader = $pageOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }
@endphp
@extends($_layout.'master')
@section('cover_title', $page_title)
@include($_lib.'register-meta')
@section('content')
    




            
         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="blog-page" >
                    <div class="container-fluid">
                        <div class="innerpage-heading text-center">
                            <h3>{{$page_title}}</h3>
                        </div><!-- end innerpage-heading -->

                        @if (count($pages))
                            @foreach ($pages as $page)
                                                    
                            <div class="blog-list-block">
                                <div class="blog-list-img">
                                    <a href="{{$u = $page->getViewUrl()}}"><img src="{{$page->getThumbnail()}}" class="img-fluid" alt="{{$page->title}}"></a>
                                </div><!-- end blog-list-img -->
                                
                                <div class="blog-list-detail">
                                    <ul class="list-inline list-unstyled">
                                        <li class="list-inline-item"><span><i class="fa fa-calendar-alt"></i></span>{{$page->dateFormat('d/n/Y')}}</li>
                                        <li class="list-inline-item"><span><i class="fa fa-user"></i></span>bởi: {{$page->author->name}}</li>
                                    </ul>
                                    <a href="{{$u}}"><h2 class="list-title">{{$page->title}}</h2></a>
                                    <p>{{$page->getShortDesc(120)}}</p>
                                    <a href="{{$u}}" class="btn btn-primary">Chi tiết</a>
                                </div><!-- end blog-list-detail -->
                            </div><!-- end blog-list-block -->

                            @endforeach
            
                            {{$pages->links($_template.'pagination')}}
                        @else
                            
                                <div class="alert alert-warning text-center">
                                    Không có kết quả phù hợp
                                </div>
                            
                        @endif

                    </div><!-- end container-fluid -->
                </div><!-- end blog-page -->
            </section><!-- end page-wrapper -->
                    
@endsection


