@php
    $pageOptions = $options->theme->posts->makeByPrefix('mobile_');
    $pageHeader = $pageOptions->makeByPrefix('page_cover_');
    
    $detailSettings = $pageOptions->makeByPrefix('detail_');
    $url = $article->getViewUrl();
    $category = $article->getCategory();
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }

@endphp

@extends($_layout.'master')
@section('cover_title', $page_title)
@include($_lib.'register-meta')



@php
    $content = '<div class="article-content">
                    '.$article->content.'
                </div>';

@endphp


@section('content')

            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="blog-details-page" >
                    <div class="{{$detailSettings->layout_type != 'fullwidth'?'container-fluid':''}}">
                        <div class="blog-list-block">
                            @if (!$detailSettings->hide_feature_image)
                                
                                <div class="blog-list-img">
                                    <img src="{{$article->getImage()}}" class="post-thumbnail" alt="{{$article->title}}" />
                                </div><!-- end blog-list-img -->
                                
                            @endif
                        
                            <div class="blog-list-detail">
                                @if (!$detailSettings->hide_meta)
                                    
                                <ul class="list-inline list-unstyled">
                                    <li class="list-inline-item"><span><i class="fa fa-calendar-alt"></i></span>{{$article->dateFormat('d/n/Y')}}</li>
                                    <li class="list-inline-item"><span><i class="fa fa-user"></i></span>bởi: {{$article->author->name}}</li>
                                </ul>
                                
                                @endif
                                @if (!$detailSettings->hide_title)
                                    
                                    <h2 class="list-title">{{$article->title}}</h2>
                                @endif

                                {!! $content !!}
                            </div><!-- end blog-list-detail -->
                        </div><!-- end blog-list-block -->
                        
                        @if (!$detailSettings->hide_comment_form)
                                    
                            @include($_template.'comments',[
                                'comments' => $article->publishComments,
                                'ref' => $article->type,
                                'ref_id' => $article->id,
                                'url' => $article->getViewUrl()
                            ])
                            
                        @endif
                    

                    </div><!-- end container-fluid -->
                </div><!-- end blog-details-page -->
            </section><!-- end page-wrapper -->
            


@endsection


