
@extends($_layout.'base')

@section('cover_title', 'Lỗi')
@section('title', '404 - Không tìm thấy')
@section('meta.robots', 'noindex')
@section('css')
    <style>
        .full-page-body{
            background: linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)),url('{{mobile_asset(images/full-page-status.jpg)}}') 100% 50%;
	        background-size: cover;
        }
    </style>
@endsection
@section('content')

        
        <!--===== FULL-PAGE-BODY ====-->
        <section class="full-page-body">
            <div class="full-page-wrapper">
                <div class="full-page-content">
                    <div class="container-fluid">
                        <div class="full-page-status text-center">
                        	<div id="error-page">
                                <div class="container-fluid text-center">
                                    <h2>4<span>0</span>4</h2>
                                    <h4>Ôi! Trang này không có</h4>
                                    <p>Trang bạn đang truy cập hiện không có hoặc đã bị xóa! Hãy dên <a href="{{route('home')}}"> Trang chủ</a> để tìm kiếm sự giúp đỡ.</p>
                                    <a href="{{route('home')}}" class="btn btn-primary btn-radius">Trang chủ</a>
                                </div><!-- end container-fluid -->
                            </div><!-- end error-page -->
                        </div><!-- end full-page-status -->
                    </div><!-- end container-fluid -->
                </div><!-- end full-page-content -->
            </div><!-- end full-page-wrapper -->
        </section><!-- end full-page-body -->
@endsection