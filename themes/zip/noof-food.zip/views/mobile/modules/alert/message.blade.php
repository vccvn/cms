@php    
    $type = (isset($type) && $type)?$type:(session('type')?session('type'):'success');
    $message = (isset($message) && $message)?$message:(session('message')?session('message'):'Hello World');
    $link = isset($link)?$link:(session('link')?session('link'):route('home'));
    $text = isset($text)?$text:(session('text')?session('text'):'<i class="fa fa-home"></i> Về trang chủ');
    $title = (isset($title) && $title)?$title:(session('title')?session('title'):null);
    
    
    $show_page_cover = 1;
    
    $page_icon = 'fa fa-info-circle';
        

@endphp
@extends($_layout.'master')
@section('cover_title', $title??'Thông báo')
@section('title', 'Thông báo')
@include($_lib.'register-meta')

@section('content')

<section class="page-wrapper innerpage-section-padding">
    <div id="error-page">
        <div class="container-fluid text-center">
            <h3>{{$title?$title:'Thông báo'}}</h3>
            <div class="alert alert-{{$type}} text-center">
                {!! $message !!}
            </div>
            <div class="buttons text-center" style="margin: 20px auto;">
                <a href="{{$link}}" class="theme-btn btn-style-two">{!! $text !!}</a>
            </div>
        </div><!-- end container-fluid -->
    </div><!-- end error-page -->
</section>

@endsection