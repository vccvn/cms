@extends($_layout . 'master')

@include($_lib.'register-meta')

@section('content')
    {!! $html->mobile_home->components !!}
@endsection
