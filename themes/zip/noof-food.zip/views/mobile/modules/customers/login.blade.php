@php
    
    $show_page_cover = 1;
    
    $page_icon = 'fa fa-user';
        
@endphp
@extends($_layout.'master')

@section('cover_title', 'Tài khoản khách hàng')
@section('title', 'Đăng nhập quản lý đơn hàng')
@include($_lib.'register-meta')

@section('content')



            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="login-page" >
                    <div class="container-fluid text-center">
                        <div class="innerpage-heading">
                            <h3>Đăng nhập tài khoản khách hàng</h3>
                            <p>Nhập email để nhận link đăng nhập</p>
                        </div><!-- end innerpage-heading -->
                        <form method="POST" action="" class="custom-form {{parse_classname('customer-login-form')}}" >
                            @csrf
                    
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="text" name="contact" class="form-control" value="{{old('contact')}}" placeholder="nhập Email hoặc số điện thoại">
                                </div>
                            </div>
                            @if ($errors->has('contact'))
                                <div class="error has-error">
                                    {{$errors->first('contact')}}
                                </div>
                            @endif
                            <div class="form-group text-center">
                                <button class="btn btn-primary">Tiếp tục</button>
                            </div>
                        
                        
                        </form>

                        
                        <div class="form-page-links">
                            <a href="{{route('client.account.login')}}">Đăng nhập</a>
                            | 
                            <a href="{{route('client.account.register')}}">Đăng ký</a>
                        </div><!-- end form-page-links -->

                    </div><!-- end container-fluid -->
                </div><!-- end login-page -->
            </section><!-- end page-wrapper -->
            


@endsection