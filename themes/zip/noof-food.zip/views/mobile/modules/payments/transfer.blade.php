@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        
        $page_icon = 'fa fa-credit-card';
        
    }

@endphp
@extends($_layout.'master')
@section('page_title', $page_title)
@section('cover_title', $page_title)
{{-- @section('title', $account->formConfig->title) --}}
@include($_lib.'register-meta')

@section('content')
            
         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="payment-page" >
                    <div class="container-fluid">
                        
                        
                        @if (!session('order_id'))

                            <form class="custom-form" action="{{route('client.payments.check-order')}}" method="POST">
                                <div class="ps-form__content">
                                    @csrf
                                    @if ($error = session('error'))
                                        <div class="alert alert-danger text-center">
                                            {{$error}}
                                        </div>
                                    @endif
                    
                                    <div class="form-group">
                                        <input type="text" name="contact" id="contact" class="form-control theme-size" value="{{old('contact')}}" placeholder="Nhập email hoặc số diện thoại">
                                        @if ($error = $errors->first('contact'))
                                            <div class="alert alert-danger text-center">
                                                {{$error}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="order_id" class="form-control theme-size" value="{{old('order_id')}}" placeholder="Mã đơn hàng">
                                        @if ($error = $errors->first('email'))
                                            <div class="alert alert-danger text-center">
                                                {{$error}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group text-center">
                                        <button type="submit" class="btn btn-primary">Tiếp tục</button>
                                    </div>
                                </div>
                            </form>
                    
                        @else
                        <div class="card order-card">
                            <a data-toggle="collapse" href="#payment-guide" data-parent="#payment-page">
                                <div class="card-header">
                                    <div class="order-title">
                                        <div class="order-name float-left">
                                            <h3><span>Hướng dãn:</h3>
                                        </div>
                                        
                                        <span class="float-right"><i class="fa fa-angle-down"></i></span>
                                    </div>
                                </div><!-- end card-header -->
                            </a>
                            <div id="payment-guide" class="collapse">
                                <div class="card-body">
                                    @include($_lib.'transfer-payment')
                                </div><!-- end card-body -->
                            </div><!-- end collapse -->
                        </div>

                        <div class="payment-form">
                            <h3 class="heading-secondary">Thanh toán</h3>
                            <div class="card-box">
                                <form class="custom-form" action="{{route('client.payments.verify-transfer')}}" method="post" enctype="multipart/form-data">
                                    <div class="ps-form__content">
                                        @csrf
                                        <input type="hidden" name="order_id" value="{{session('order_id')}}">
                                        <div class="form-group">
                                            <label class="form__label" for="order_id">
                                                Mã đơn hàng <span>*</span>
                                            </label>
                                            <input type="text" name="order_id" class="form-control" value="{{session('order_id')}}" placeholder="Mã đơn hàng" readonly>
                                        </div>
                                        @if ($error = $errors->first('email'))
                                            <div class="alert alert-danger text-center">
                                                {{$error}}
                                            </div>
                                        @endif
                                        
                                        <div class="form-group">
                                            <label for="billing_transaction_image" class="form__label">Biên lai <span>*</span></label>
                                            <div class="custom-file {{parse_classname('custom-file')}}">
                                                <input type="file" name="image" id="billing_transaction_image" class="custom-file-input">
                                                <label class="custom-file-label" for="billing_transaction_image">Chưa có file nào dc chọn</label>
                                            </div>
                                            @if ($errors->has('image'))
                                                <div class="error has-error">{{$errors->first('image')}}</div>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <label for="orderNotes" class="form__label">Ghi chú </label>
                                            <textarea class="form-control" id="orderNotes" name="note" placeholder="Ghi chú (Tùy chọn)">{{old('note')}}</textarea>
                                        </div>
                                        <div class="form-group  text-center">
                                            <button type="submit" class="btn btn-primary">Gửi</button>
                                        </div>
                                        
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                        @endif
                    </div><!-- end container-fluid -->
                </div><!-- end register-page -->
            </section><!-- end page-wrapper -->
            
@endsection

@section('css')
    <style>
        h3.title{
            margin-bottom: 40px;
            text-align: center;
            line-height: 1;
        }

        h3.heading-secondary{
            font-size: 25px;
            text-align: center;
        }
        .card-box h4{
            font-size: 18px;
        }
        
    </style>
@endsection