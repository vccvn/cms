@php
    $postOptions = $options->theme->posts->makeByPrefix('desktop_');
    $pageHeader = $postOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')
    <!--=================== PAGE-WRAPPER ================-->
    <section class="page-wrapper innerpage-section-padding">
        <div id="blog-page" >
            <div class="container-fluid">
                <div class="innerpage-heading text-center">
                    <h3>{{$page_title}}</h3>
                </div><!-- end innerpage-heading -->
                <div class="alert alert-warning text-center">
                    Không có kết quả phù hợp
                </div>
            </div><!-- end container-fluid -->
        </div><!-- end blog-page -->
    </section><!-- end page-wrapper -->
            
@endsection



