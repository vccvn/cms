@php
    $postOptions = $options->theme->posts->makeByPrefix('mobile_');
    $pageHeader = $postOptions->makeByPrefix('page_cover_');
    
    $detailSettings = $postOptions->makeByPrefix('detail_');
    $url = $article->getViewUrl();
    $category = $article->getCategory();
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }

@endphp

@extends($_layout.'master')
@section('cover_title', $dynamic->name)
@include($_lib.'register-meta')


@if (($article->contentType('gallery') || $dynamic->post_type == 'gallery') && $galleries = $article->gallery)
    @if (count($galleries))
        @section('gallery')
            <ul id="menu-gallery" class="gallery list-unstyled cS-hidden menu-gallery text-center">
                @if (count($product->gallery))
                    @foreach ($galleries as $item)
                        <li data-thumb="{{$item->getUrl()}}"> 
                            <div class="p-img">
                                <img src="{{$item->getUrl()}}" alt="{{$product->name}}"/>
                            </div>
                        </li>
                    @endforeach
                @endif
            </ul>
        @endsection
    @endif
@endif

@php
    $gallery = $__env->yieldContent('gallery');
    $content = '<div class="article-content">
                    '.$article->content.'
                </div>';
    
    if($gallery){
        $args = [];
        if($gallery){
            if(preg_match('/[^\{}]\{\$gallery\}[^\}]/i', $content)){
                $args['gallery'] = $gallery;
            }else{
                $content = $gallery.$content;
                $detailSettings->hide_feature_image = true;
            }
        }
        $content = str_eval($article->content, $args);

    }
@endphp


@section('content')

            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="blog-details-page" >
                    <div class="container-fluid">
                        @if ($article->category)
                                
                            <div class="innerpage-heading text-center">
                                <h3>{{$article->category->name}}</h3>
                            </div><!-- end innerpage-heading -->
                            
                        @endif
                        <div class="blog-list-block">
                            @if ($article->contentType('embed') && $video = $article->getVideo())
                                <div class="embed-responsive">
                                    <iframe width="560" height="315" src="{{$video->embed_url}}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                            
                            @else
                                @if (!$detailSettings->hide_feature_image)
                                    
                                    <div class="blog-list-img">
                                        <img src="{{$article->getImage()}}" class="post-thumbnail" alt="{{$article->title}}" />
                                    </div><!-- end blog-list-img -->
                                    
                                @endif
                            
                            @endif
                            <div class="blog-list-detail">
                                <ul class="list-inline list-unstyled">
                                    <li class="list-inline-item"><span><i class="fa fa-calendar-alt"></i></span>{{$article->dateFormat('d/n/Y')}}</li>
                                    <li class="list-inline-item"><span><i class="fa fa-user"></i></span>bởi: {{$article->author->name}}</li>
                                </ul>
                                <h2 class="list-title">{{$article->title}}</h2>

                                {!! $content !!}
                            </div><!-- end blog-list-detail -->
                        </div><!-- end blog-list-block -->
                        
                        @if ($detailSettings->show_comment_form)
                                    
                            @include($_template.'comments',[
                                'comments' => $article->publishComments,
                                'ref' => $article->type,
                                'ref_id' => $article->id,
                                'url' => $article->getViewUrl()
                            ])
                            
                        @endif
                    

                    </div><!-- end container-fluid -->
                </div><!-- end blog-details-page -->
            </section><!-- end page-wrapper -->
            


@endsection


