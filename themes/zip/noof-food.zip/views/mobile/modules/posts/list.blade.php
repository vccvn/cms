@php
    $postOptions = $options->theme->posts->makeByPrefix('desktop_');
    $pageHeader = $postOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }
@endphp
@extends($_layout.'master')
@section('cover_title', $dynamic->name)
@include($_lib.'register-meta')
@section('content')
         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="blog-page" >
                    <div class="container-fluid">
                        <div class="innerpage-heading text-center">
                            <h3>{{$page_title}}</h3>
                        </div><!-- end innerpage-heading -->

                        @if (count($posts))
                            @foreach ($posts as $post)
                                                    
                            <div class="blog-list-block">
                                <div class="blog-list-img">
                                    <a href="{{$u = $post->getViewUrl()}}"><img src="{{$post->getThumbnail()}}" class="img-fluid" alt="{{$post->title}}"></a>
                                </div><!-- end blog-list-img -->
                                
                                <div class="blog-list-detail">
                                    <ul class="list-inline list-unstyled">
                                        <li class="list-inline-item"><span><i class="fa fa-calendar-alt"></i></span>{{$post->dateFormat('d/n/Y')}}</li>
                                        <li class="list-inline-item"><span><i class="fa fa-user"></i></span>bởi: {{$post->author->name}}</li>
                                    </ul>
                                    <a href="{{$u}}"><h2 class="list-title">{{$post->title}}</h2></a>
                                    <p>{{$post->getShortDesc(120)}}</p>
                                    <a href="{{$u}}" class="btn btn-primary">Chi tiết</a>
                                </div><!-- end blog-list-detail -->
                            </div><!-- end blog-list-block -->

                            @endforeach
            
                            {{$posts->links($_template.'pagination')}}
                        @else
                            
                                <div class="alert alert-warning text-center">
                                    Không có kết quả phù hợp
                                </div>
                            
                        @endif

                    </div><!-- end container-fluid -->
                </div><!-- end blog-page -->
            </section><!-- end page-wrapper -->
                    
@endsection


