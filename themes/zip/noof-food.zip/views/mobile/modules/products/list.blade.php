@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    // $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    // if($pageHeader->show){
    //     $show_page_cover = 1;
    //     if($pageHeader->icon){
    //         $page_icon = $pageHeader->icon;
    //     }
    // }
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('cover_title', 'Shop')
@section('content')


            <!--========= PAGE-COVER =========-->
            <div class="bg-color-primary">
                <div class="container-fluid">
                    <form method="GET" action="{{route('client.products')}}" >
                        <div class="form-group mb-0 pt-2 pb-2">
                            <div class="input-group">
                                <input type="search" name="search" class="form-control" value="{{$request->search}}">
                                <div class="input-group-append">
                                    <button class="btn btn-black mt-0"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div><!-- end container-fluid -->
            </div><!-- end page-cover -->
            
         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="menu-page" class="menu-grid">
                    <div class="container-fluid text-center menu">
                        <div class="innerpage-heading">
                            <h3>{{$page_title}}</h3>
                        </div><!-- end innerpage-heading -->
                        
                        @if ($t = count($products))
                        
                            <div class="products">
                                <ul class="list-unstyled">
                                    @foreach ($products as $product)
                                        @php
                                            $hasOption = $product->hasOption();
                                            $votes = $product->getReviewPoints();
                                            $intVote = (int) $votes;
                                            $max = $intVote < $votes ? $intVote + 1 : $intVote;
                                            $hasPromo = $product->hasPromo();
                                            $name = str_limit($product->name, 40);


                                            $reviews = $product->getReviewData();
                                        @endphp
                                        <li>
                                            <div class="dish-list">
                                                <a href="{{$u = $product->getViewUrl()}}"><img src="{{$product->getThumbnail()}}" class="img-fluid" alt="{{$product->name}}" /></a>
                                                <div class="dish-list-text">
                                                    <h4><a href="{{$u}}">{{$product->sub('name', 40, '...')}}</a></h4>
                                                    <h5>{{$product->priceFormat('final')}}</h5>
                                                    {{-- <p>{{$product->getShortDesc(120)}}</p> --}}
                                                    @if ($allow_place_order)

                                                        <a href="{{$hasOption?$u:'javascript:void(0)'}}" class="btn btn-primary {{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}">Thêm giỏ hàng <span><i class="fa fa-shopping-cart"></i></span></a>
                                                    
                                                    @endif
                                                </div><!-- end dish-list-text -->
                                            </div><!-- end dish-list -->
                                        </li>
                                        

                                    @endforeach
                                </ul>
                            </div>
                            
                            <div class="list-pagination">
                                {{$products->links($_template.'pagination')}}
                            </div>
                            
                        @else
                            <div class="text-center alert alert-warning">
                                Danh sách trống
                            </div>
                        @endif
                    </div><!-- end container-fluid -->
                </div><!-- end menu-page -->
            </section><!-- end page-wrapper -->
            
            




@endsection


