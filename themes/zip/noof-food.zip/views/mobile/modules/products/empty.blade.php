@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('cover_title', 'Shop')
@section('content')

         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="menu-page" class="menu-grid">
                    <div class="container-fluid text-center menu">
                        <div class="innerpage-heading">
                            <h3>{{$page_title}}</h3>
                        </div><!-- end innerpage-heading -->
                        
                            <div class="text-center alert alert-warning">
                                Danh sách trống
                            </div>
                    </div><!-- end container-fluid -->
                </div><!-- end menu-page -->
            </section><!-- end page-wrapper -->
            
            




@endsection




