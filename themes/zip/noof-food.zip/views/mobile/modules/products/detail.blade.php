@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        if($pageHeader->icon){
            $page_icon = $pageHeader->icon;
        }
    }

    $hasOption = $product->hasOption();
    $hasPromo = $product->hasPromo();
    $reviews = $product->getReviewData();
    $votes = $product->getReviewPoints();
    $intVote = (int) $votes;
    $max = $intVote < $votes ? $intVote + 1 : $intVote;
    $u = $product->getViewUrl();

@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('cover_title', 'Shop')
@section('content')


         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="menu-detail-page" class="{{parse_classname('product-detail')}}">
                    <div class="container-fluid">
                        <div class="menu-detail {{parse_classname('product-detail-info', 'product-detail-info-'.$product->id)}}" id="product-detail-{{$product->id}}" data-id="{{$product->id}}">
                            <div class="menu-title">
                                <div class="menu-name">
                                    <h3>
                                        {{$product->name}}
                                    </h3>
                                </div>
                            </div><!-- end menu-title -->
                            
                            <ul id="menu-gallery" class="gallery list-unstyled cS-hidden menu-gallery text-center">
                                <li data-thumb="{{$thumb = $product->getThumbnail()}}">
                                    <div class="p-img">
                                        <img src="{{$thumb}}" alt="{{$product->name}}">
                                    </div>
                                </li>
                                @if (count($product->gallery))
                                    @foreach ($product->gallery as $item)
                                        <li data-thumb="{{$item->getUrl()}}"> 
                                            <div class="p-img">
                                                <img src="{{$item->getUrl()}}" alt="{{$product->name}}"/>
                                            </div>
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                            
                            <div class="menu-info">
                                @if ($reviews->total)
                                    <ul class="list-unstyled list-inline star-rating">
                                        @for ($i = 1; $i < 6; $i++)
                                            <li class="list-inline-item">
                                                <span>
                                                    @if ($i <= $intVote)
                                                        <i class="fa fa-star"></i>

                                                    @elseif($i > $intVote && $i == $max)
                                                        <i class="fas fa-star-half-alt"></i>
                                                    @else
                                                        <i class="fas fa-star-alt"></i>
                                                    @endif
                                                </span>
                                            </li>
                                        @endfor
                                    </ul>
                                    
                                    
                                @endif
                                <p>{{$product->getShortDesc(500)}}</p>
                                <div class="menu-title">
                                    <div class="menu-price">
                                        <h4>Giá bán: <span class="text-primary {{parse_classname('product-price')}}">{{$product->priceFormat('final')}}</span> </h4>
                                        
                                    </div>
                                </div><!-- end menu-title -->
                                
                            
                                @if ($product->affiliates && count($product->affiliates))
                    
                                    <div class="ps-product__desc">
                                        <div class="ps-list--dot">
                                            Sản phẩm hiện có trên: 
                                        </div>
                                        <div class="affiliates product-affiliates">
                                            <div class="row">
                                                @php
                                                    $affiliateOptions = $options->theme->shop->makeByPrefix('affiliate_');
                                                @endphp
                                                @foreach ($product->affiliates as $affiliate)
                                                    @php
                                                        if($mas = nooffood_affiliate_settings($affiliate->id)){
                                                            $a = $mas;
                                                        }else{
                                                            $a = $affiliateOptions;
                                                        }
                                                        $color = $a->color;
                                                        $border_color = $a->border_color($a->color);
                                                        $logo_background_color = $a->logo_background_color;
                                                        $logo_text_color = $a->text_color_color($logo_background_color?'#fff':'');
                                                        $price_background_color = $a->price_background_color;
                                                        $price_text_color = $a->price_text_color($color);
                                                    @endphp
                                                    <div class="col-sm-6 ">
                                                        <a href="{{$affiliate->url}}">
                                                            <div class="row affiliate-item product-affiliate-item" style="{{$border_color? 'border-color: ' . $border_color . '; ' : ''}}">
                                                                <div class="col-5 affiliate-logo" style="{{$logo_background_color?'background-color: ' . $logo_background_color . '; ' : ''}}{{$logo_text_color?'color: ' . $logo_text_color : ''}}">
                                                                    <img src="{{$affiliate->logo_url}}" alt="{{$affiliate->name}}">
                                                                </div>
                                                                <div class="col-7 affiliate-price" style="{{$price_background_color ? 'background-color: ' . $price_background_color . '; ' : ''}}{{$price_text_color?'color: ' . $price_text_color : ''}}">
                                                                    {{$affiliate->priceFormat()}}
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    
                                @endif
                                @if ($allow_place_order)
                                
                                <form action="{{route('client.orders.add-to-cart')}}" method="post" class="{{parse_classname('product-order-form')}}">
                                    <div class="variants">

                                        {!!
                                            $product->attributesToHtml([
                                                'section_class' => '',
                                                'attribute_class' => '',
                                                'attribute_name_class' => '',
                                                'value_list_class' => '',
                                                'value_item_class' => '',
                                                'select_class' => '',
                                                'image_class' => '',
                                                'value_text_class' => '',
                                                'radio_class' => '',
                                                'value_label_class' => ''
                                            ])
                                        !!}

                                    </div>
                                    <p><label for="product-quantity">Số lượng</label></p>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input id="product-quantity" class="form-control {{parse_classname('product-order-quantity', 'quantity')}} inp-quantity" type="number" name="quantity" min="1" step="1" placeholder="1" value="1">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary">Thêm giỏ hàng <span><i class="fa fa-shopping-cart"></i></span></button>
                                            </div>
                                        </div>
                                   </div>
                                    
                                </form>
                                
                                @endif
                                
                            </div><!-- end menu-info -->
                            
                            <ul class="nav nav-tabs justify-content-center">
                                <li class="nav-item"><a class="nav-link active" href="#description" data-toggle="tab"><span><i class="fa fa-info"></i></span>Chi tiết</a></li>
                                <li class="nav-item"><a class="nav-link" href="#reviews" data-toggle="tab"><span><i class="fa fa-comments"></i></span>Đánh giá</a></li>
                            </ul>
                            
                            <div class="tab-content">
                                <div id="description" class="tab-pane active">
                                    {!! $product->detail !!}
                                </div>
                                
                                <div id="reviews" class="tab-pane fade">
                                    <div class="comments-wrapper">
                                        @if (count($product->reviews))
                                            @foreach ($product->reviews as $review)
                                                <div class="comment-block">
                                                    <h4>{{$review->review_name}}</h4>
                                                    <ul class="list-unstyled list-inline star-rating">
                                                        @for ($i = 0; $i < $review->rating; $i++)
                                                            <li class="list-inline-item"><span><i class="fa fa-star"></i></span></li>
                                                        @endfor
                                                    </ul>
                                                    {{-- <p>Thời gian: {{$review->dateFormat('H:i')}} - ngày {{$review->dateFormat('d/m/Y')}}</p> --}}
                                                    <p>{{$review->comment}}</p>
                                                    {{-- <a href="#"><span><i class="fa fa-reply"></i></span>Reply</a> --}}
                                                </div><!-- end comment-block -->
                                                    
                                                
                                            @endforeach
                                        @endif
                                    </div>
                                    <form class="custom-form {{parse_classname('product-review-form')}}" action="{{route('client.products.review')}}" method="post">
                                        @csrf 
                                        <input type="hidden" name="product_id" value="{{$product->id}}">
                                        <h3>Gửi đánh giá</h3>
                                        <div class="form-group">
                                             <input class="form-control {{parse_classname('auto-fill', 'fill-name')}}" type="text" name="name" placeholder="Họ tên">
                                        </div>
                    
                                        <div class="form-group">
                                            <input class="form-control {{parse_classname('auto-fill', 'fill-email')}}" type="email" name="email" placeholder="Email">
                                        </div>
                                        <div class="ratings">
                                            <span class="rating-title">Đánh giá : </span>
                                            <select class="ps-rating" data-read-only="false" name="rating">
                                                <option value="0">0</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <textarea name="comment" class="form-control" rows="6" placeholder="Viết đánh giá của bạn..."></textarea>
                                        </div>
                                        
                                        <button class="btn btn-primary btn-radius">Gửi đánh giá</button>
                                    </form>
                                </div><!-- end reviews -->
                            </div><!-- end tab-content -->
                        </div>
                    </div><!-- end container-fluid -->
                </div><!-- end menu-detail-page -->
            </section><!-- end page-wrapper -->

@endsection


@section('css')

    <!-- Lightslider Stylesheets -->	
    <link rel="stylesheet" href="{{mobile_asset('css/lightslider.css')}}">
    <link rel="stylesheet" href="{{desktop_asset('plugins/jquery-bar-rating-master/dist/themes/fontawesome-stars.css')}}">
@endsection
@section('js')



    <script src="{{mobile_asset('js/lightslider.js')}}"></script>
    <script src="{{mobile_asset('js/custom-lightslider.js')}}"></script>

    <script src="{{desktop_asset('plugins/jquery-bar-rating-master/jquery.barrating.js')}}"></script>
    <script>
        $(function() {
            $('.ps-rating').barrating({
                theme: 'fontawesome-stars'
            });
        });
    </script>
@endsection