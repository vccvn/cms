@php
    $show_page_cover = 1;
    $page_icon = 'fa fa-user';
@endphp
@extends($_layout.'master')

@section('cover_title', 'Tài khoản')
@section('title', 'Đăng ký tài khoản')
@section('page_type', 'my-account')

@section('content')



<!--=================== PAGE-WRAPPER ================-->
<section class="page-wrapper innerpage-section-padding">
    <div id="register-page" >
        <div class="container-fluid text-center">
            <div class="innerpage-heading">
                <h3>Đăng nhập</h3>
                {{-- <p>Nhập email để nhận link đặt lại mật khẩu</p> --}}
            </div><!-- end innerpage-heading -->
            <form method="POST" action="{{route('client.account.post-register')}}" class="custom-form {{parse_classname('customer-login-form')}}" >
                @if ($next = old('next', $request->next))
                <input type="hidden" name="next" value="{{$next}}">
            @endif
            @php
                $registerForm = $html->getRegisterForm([
                    'class' => 'form-control theme-size'
                ]);
            @endphp
            @csrf
            
                @if ($registerForm && $inputs = $registerForm->inputs())
                    @foreach ($inputs as $input)
                    <div class="form-group">
                        {!! $input->type!="checkbox"?$input:$input->removeClass('form-control') !!}
                        @if ($input->error)
                        <div class="has-error error">{{$input->error}}</div>
                        @endif
                    </div>
                    @endforeach
                @endif
                
                <div class="form-group text-center">
                    <button class="btn btn-primary">Đăng ký</button>
                </div>
            
            
            </form>


            
            <div class="form-page-links">
                Bạn đã có tài khoản trước rồi? <a href="{{route('client.account.login')}}">Dăng nhập</a>
                <p>
                    <a href="{{route('client.account.forgot')}}">Quên mật khẩu</a>
                </p>
                
            </div><!-- end form-page-links -->

        </div><!-- end container-fluid -->
    </div><!-- end login-page -->
</section><!-- end page-wrapper -->


@endsection