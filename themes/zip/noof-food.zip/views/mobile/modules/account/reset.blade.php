@php
    $show_page_cover = 1;
    $page_icon = 'fa fa-user';
@endphp
@extends($_layout.'master')

@section('cover_title', 'Tài khoản')
@section('title', 'Tạo mật khẩu mới')

@section('content')


            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="login-page" >
                    <div class="container-fluid text-center">
                        <div class="innerpage-heading">
                            <h3>Tạo mật khẩu mới</h3>
                            <p>Hãy sử dụng một mật khẩu an toàn và khóa đoán, tránh sử dụng các mật khẩu đễ doán như 123456 hay ngày tháng năm sinh của bạn hay của ai đó.</p>
                        </div><!-- end innerpage-heading -->
                        <form method="POST" action="{{route('client.account.password.reset')}}" class="custom-form {{parse_classname('customer-login-form')}}" >
                            @if ($next = old('next', $request->next))
                                <input type="hidden" name="next" value="{{$next}}">
                            @endif
                            @csrf
                        
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control theme-size" type="password" name="password" placeholder="Mật khẫu">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                                    </div>
                                </div>
                                
                            </div>
                            
                            @if ($error = session('error'))
                                <div class="alert alert-danger text-center">
                                    {{$error}}
                                </div>
                            @endif
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control theme-size" type="password" name="password_confirmation" placeholder="Nhập lại mật khẩu">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary btn-radius">Tạo mật khẩu</button>
                            </div>
                        
                        
                        </form>


                        
                        <div class="form-page-links">
                            <a href="{{route('client.account.forgot')}}">Quên mật khẩu?</a>
                            <p>
                                Chưa có tài khoản? <a href="{{route('client.account.register')}}">Đăng ký</a> ngay!
                            </p>
                            
                        </div><!-- end form-page-links -->

                    </div><!-- end container-fluid -->
                </div><!-- end login-page -->
            </section><!-- end page-wrapper -->






@endsection