@php
    $show_page_cover = 1;
    $page_icon = 'fa fa-user';
@endphp
@extends($_layout.'master')

@section('cover_title', 'Tài khoản')
@section('title', $account->formConfig->title)
@include($_lib.'register-meta')

@section('content')



<!--=================== PAGE-WRAPPER ================-->
<section class="page-wrapper innerpage-section-padding">
    <div id="register-page" >
        <div class="container-fluid text-center">
            <div class="innerpage-heading">
                <h3>{{$account->formConfig->title}}</h3>
                {{-- <p>Nhập email để nhận link đặt lại mật khẩu</p> --}}
            </div><!-- end innerpage-heading -->
            
            <div class="card order-card">
                <a data-toggle="collapse" href="#account-panal" data-parent="#register-page">
                    <div class="card-header">
                        <div class="order-title">
                            <div class="order-name float-left">
                                <h3><span>Menu</h3>
                            </div>
                            
                            <span class="float-right"><i class="fa fa-angle-down"></i></span>
                        </div>
                    </div><!-- end card-header -->
                </a>
                <div id="account-panal" class="collapse">
                    <div class="card-body pt-0 pl-0 pr-0">
                        <ul class="list-unstyled v-menu">
                            @foreach ($account->settings as $sk => $item)
                                <li><a class="{{$account->tab == $sk ? "active":""}}" href="{{route('client.account.settings', ['tab' => $item->slug])}}">{{$item->title}}</a></li>
                            @endforeach
                            <li><a class="" href="{{route('client.orders.manager')}}">Quản lý đơn hàng</a></li>
                            <li><a class="" href="{{route('client.account.logout')}}">Thoát</a></li>
                        </ul>
                    </div><!-- end card-body -->
                </div><!-- end collapse -->
            </div>

            <div class="card-box">
                <form method="POST" action="{{route('client.account.settings', ['tab' => $account->formConfig->slug])}}" class="custom-form">
                    @csrf
                    @if ($message = session('message'))
                        <div class="alert alert-success mb-3">
                            {{$message}}
                        </div>
                    @elseif($error = session('error'))
                        <div class="alert alert-danger mb-3">
                            {{$error}}
                        </div>
                    @endif
                    @if ($form = $account->form)
                        <?php
                            $form->map('addClass', 'form-control');
                        ?>
                        @foreach ($form as $input)
                            <div class="form-group">
                                {!!$input!!}
                                @if ($input->error)
                                    <div class="error has-error text-danger">{{$input->error}}</div>
                                @endif
                        
                            </div> 
                        
                        @endforeach
                    @endif
                    
                    <div class="form-group text center">
                        <button type="submit" class="btn btn-primary btn-radius">Cập nhật</button>
                    </div>
                </form>
            </div>


        </div><!-- end container-fluid -->
    </div><!-- end login-page -->
</section><!-- end page-wrapper -->

@endsection