@php
$contacts = $options->theme->contacts;
    $show_page_cover = 1;
    $page_icon = 'fa fa-phone';
    $page_title = $contacts->page_title('Liên hệ');
    $socials = $options->theme->socials;
    $list = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin'];
@endphp
@extends($_layout.'master')
@section('title', $page_title)

@section('cover_title', $page_title)

@if ($contacts->page_description)
    @section('meta_description', $contacts->page_description)
@endif

@include($_lib.'register-meta')

@section('content')

            <!--======================== PAGE-WRAPPER ===================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="contact-page">
                    <div class="container-fluid text-center">
                        <div class="innerpage-heading">
                            <h3>{{$contacts->page_title}}</h3>
                            <p>{{$contacts->page_description}}</p>
                        </div><!-- end innerpage-heading -->
                        <div class="embed-map">
                            {!! $contacts->map_code !!}
                        </div>
                        <form name="contact-form" method="post" action="{{route('client.contacts.send')}}" data-ajax-url="{{route('client.contacts.ajax-send')}}" class="custom-form {{parse_classname('contact-form')}} " id="contact-formx"> 
                            <div class="form-group">
                                 <input type="text" class="form-control" name="name" id="name" placeholder="Họ và tên *"/>
                            </div>
        
                            <div class="form-group">
                                 <input type="email" class="form-control" name="email" id="email" placeholder="Địa chỉ e-mail *" />
                            </div>
                            
                            <div class="form-group">
                                 <input type="text" class="form-control" name="phone_number" id="phone_number" placeholder="Số điện thoại (tùy chọn)" />
                            </div>
                            
                            <div class="form-group">
                                 <input type="text" class="form-control" placeholder="Subject (tùy chob5)" name="subject" id="subject" />
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="5" name="message" placeholder="Nội dung *"></textarea>
                            </div>
                            <div class="col-sm-12 text-center" id="result_msg"></div>
                            <button class="btn btn-primary btn-radius"  name="submit" id="submit">Gửi liên hệ</button>
                        </form>
                    </div><!-- end container-fluid -->
                </div><!-- end contact-page -->
            </section><!-- end page-wrapper -->
            
            



@endsection

@section('js')
    <script>
        App.query('.embed-map iframe').addClass('map');
    </script>
@endsection