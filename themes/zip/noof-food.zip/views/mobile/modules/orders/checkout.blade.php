@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        
        $page_icon = 'fa fa-shopping-carT';
        
    }

@endphp
@extends($_layout.'master')
@section('page_title', $page_title)
@section('cover_title', $page_title)
@section('title', $page_title)
@include($_lib.'register-meta')

@section('content')


            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="checkout-page" >
                    <div class="container-fluid">
                        <div class="innerpage-heading text-center">
                            <h3>Đơn hàng</h3>
                            <a href="{{route('client.orders.cart')}}" class="btn btn-primary">Xem giỏ hàng</a>
                        </div><!-- end innerpage-heading -->
                        
                        @if ($cart && $cart->details && count($cart->details))


                            <div class="order-list">
                                <ul class="list-unstyled">
                                    @foreach ($cart->details as $item)
                                        <li class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                            <div class="order">
                                                <div class="order-item">
                                                    <div class="order-item-info">
                                                        <h4><a href="{{$item->link}}">{{$item->product_name}}</a></h4>
                                                    
                                                        @if ($item->attributes && count($item->attributes))
                                                            @foreach ($item->attributes as $attr)
                                                                <p>{{$attr->label??$attr->name}}: <strong>{{$attr->text}}</strong></p>
                                                            @endforeach
                                                        @endif
                                                        <p class="order-item-price"><span>Giá : {{$item->getPriceFormat()}}</span> , Số lượng : {{$item->quantity}}</p>
                                                    </div><!-- end order-item-info -->
            
                                                    <div class="order-item-img">
                                                        <a href="{{$item->link}}"><img src="{{$item->image}}" class="img-fluid" alt="{{$item->product_name}}" /></a>
                                                    </div><!-- end order-img -->
                                                </div><!-- end order-item -->
                                                
                                                <div class="total">
                                                    <p>{{$item->quantity}} x {{$item->getPriceFormat()}} = <span>{{$item->getTotalFormat()}}</span></p>
                                                </div><!-- end total -->
                                            </div><!-- end order-->
                                        </li>
                                    @endforeach

                                </ul>
                                <div class="cart-info text-center">
                                    <h4>Tổng thành tiền: <span class="{{parse_classname('cart-total-ammount')}}">{{$helper->getCurrencyFormat($cart->total_money)}}</span></h4>
                                </div><!-- end cart-info -->
                            </div>
                            
                            <form class="custom-form {{parse_classname('checkout-form', 'place-order-form')}}" action="{{route('client.orders.place-order')}}" method="post"> 
                                <h4>Thông tin đặt hàng:</h4>
                                @php
                                    $form = $cart->getForm([
                                        'className' => 'form-control'
                                    ]);
                                    $info = $form->get('billing_name', 'billing_email', 'billing_phone_number', 'billing_region_id', 'billing_district_id', 'billing_ward_id', 'billing_address');
                                    $shipping = $form->get('shipping_name', 'shipping_email', 'shipping_phone_number', 'shipping_region_id', 'shipping_district_id', 'shipping_ward_id', 'shipping_address');
                                @endphp
                                @csrf
                                <div class="billing-info">
                                    @foreach ($info as $input)
                                        
                                        <div class="form-group">
                                            
                                            {!! $input !!}
                                            @if ($input->error)
                                                <div class="error has-error">{{$input->error}}</div>
                                            @endif
                                        </div>
                                    @endforeach
                                    @if (!$helper->isLogin())
                                        <div class="account-group {{parse_classname('account-group')}}">
                                            <div class="form-group">
                                                {{-- <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck">
                                                    <label class="custom-control-label" for="customCheck">I agree that i have read and accepted the <a href="#">terms &amp; conditions</a></label>
                                                </div> --}}
                                                <div class="ps-checkbox">
                                                    {!! $create = $form->get('create_account')->addClass(parse_classname('create-account-checkbox') . ' mr-2')->removeClass('form-control') !!}
                                                </div>
                                            </div>

                                            <div class="create-account-group {{parse_classname('create-account-group')}} {{$create->value?'show':''}}">
                                                <p>Tạo một tài khoản từ thông tin đơn hàng. Lần tới mua hàng bạn có thể dùng tài khoản này để đặt hàng dễ dàng hơn và tiện quản lý</p>
                                                <div class="form-group">
                                                    
                                                    {!! $input !!}
                                                    @if ($input->error)
                                                        <div class="error has-error">{{$input->error}}</div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    @endif

                                    <div class="shipping-group {{parse_classname('shipping-group')}}">
                                        <div class="form-group">
                                            <div class="ps-checkbox">
                                                {!! $checkbox = $form->get('ship_to_different_address')->addClass(parse_classname('ship-to-different-address') . ' mr-2')->removeClass('form-control') !!}
                                            </div>
                                        </div>
                                        <div class="shipping-address-group {{parse_classname('shipping-address-group')}} {{$checkbox->value?'show':''}}">
                                            @foreach ($shipping as $input)
                                        
                                                <div class="form-group">
                                                    {!! $input !!}
                                                    @if ($input->error)
                                                        <div class="error has-error">{{$input->error}}</div>
                                                    @endif
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>

                                    {{-- <h3 class="mt-40"> Addition information</h3> --}}
                                    <div class="form-group">
                                        
                                        {!! $form->note !!}
                                    </div>
                                    <div class="checkout-payment {{parse_classname('payment-methods')}}">
                                        @if (count($methods = $helper->getOrderPaymentMethods()))
                                            <?php 
                                            $defaultMethod = old('payment_method')??(isset($methods[0])?$methods[0]->value:0);
                                            ?>
                                            @foreach ($methods as $method)
                                                <div class="payment-group {{parse_classname('payment-method-option')}}">
                                                    <div class="form-group">
                                                        <div class="ps-radio">
                                                            <input type="radio" class="{{parse_classname('payment-method-value')}}" value="{{$method->value}}" name="payment_method" id="payment-method-{{$method->value}}" @if($method->value == $defaultMethod) checked @endif>
                                                            <label class="payment-label {{parse_classname('payment-method-label')}}" for="payment-method-{{$method->value}}">{{$method->name}}</label>
                                                        </div>
                                                        <div class="{{parse_classname('payment-method-description', 'payment-method-description-'.$method->value)}} {{$method->value == $defaultMethod ? 'show' : ''}}" data-method="{{$method->value}}" id="payment-description-{{$method->value}}">
                                                            <p>{{$method->description}}</p>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                            @endforeach
                                        @endif
                                    </div>
        
                                </div>
                                <button class="btn btn-primary btn-radius">Đặt hàng</button>
                            </form>
                        @else
                            <div class="text-center">
                                <h3>Không có sản phẩm nào trong giỏ hàng</h3>
                            </div>
                        @endif
                        
                    </div><!-- end container-fluid -->
                </div><!-- end checkout-page -->
            </section><!-- end page-wrapper -->
            





@endsection