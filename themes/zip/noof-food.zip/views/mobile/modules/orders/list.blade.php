@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        
        $page_icon = 'fa fa-shopping-card';
        
    }

    $orderStatus = [
        0 => [
            'label' => 'info',
            'icon' => 'fa fa-rocket'
        ],
        100 => [
            'label' => 'info',
            'icon' => 'fa fa-rocket'
        ],
        
        200 => [
            'label' => 'info',
            'icon' => 'fa fa-credit-card',

        ],
        300 => [
            'label' => 'info',
            'icon' => 'fa fa-credit-card',

        ],
        400 => [
            'label' => 'info',
            'icon' => 'fa fa-clock',

        ],
        500 => [
            'label' => 'info',
            'icon' => 'fa fa-truck',

        ],
        1000 => [
            'label' => 'success',
            'icon' => 'fa fa-check',

        ],

        -1 => [
            'label' => 'fail',
            'icon' => 'fa fa-times',

        ]
    ];
@endphp
@extends($_layout.'master')
@section('page_title', $page_title)
@section('cover_title', $page_title)
@section('title', $page_title)
@include($_lib.'register-meta')

@section('content')


         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="order-history-page" >
                    <div class="container-fluid">
                        <div class="innerpage-heading text-center">
                            <h3>Đơn hàng của tôi</h3>
                        </div><!-- end innerpage-heading -->
                        
                        <div class="form-group">
                        	<select class="form-control">
                                <option value="{{route('client.orders.manager')}}" selected>Tất cả đơn hàng</option>
                                @foreach ($status_list as $item)

                                <option value="{{route('client.orders.list', ['status_key' => $status_keys[$item->key]])}}">{{$item['label']}}</option>

                                @endforeach
                            	
                            </select>
                            <span><i class="fa fa-calendar-alt"></i></span>
                            <span><i class="fa fa-angle-down"></i></span>
                        </div>
                        @if (count($orders))
                            @foreach ($orders as $order)
                            @php
                                $os = $orderStatus[$order->status]??$orderStatus[0];
                            @endphp
                                <div class="card order-card">
                                    <a data-toggle="collapse" href="#order-{{$order->id}}" data-parent="#order-history-page">
                                        <div class="card-header">
                                            <div class="order-title">
                                                <div class="order-name float-left">
                                                    <h3><span>Mã đơn hàng:</span> #{{$order->id}}</h3>
                                                    
                                                </div>
                                                <span class="order-status {{$os['label']}} float-right">
                                                    <span class="status-text">{{$order->getStatusLabel()}}</span> <i class="{{$os['icon']}}"></i>
                                                </span>
                                                <div class="order-name clearfix">
                                                    <ul class="list-inline float-left">
                                                        <li class="list-inline-item"><i class="fa fa-calendar-alt"></i> {{$order->getDatetime('ordered_at', 'd/m/Y')}}</li> 
                                                        <li class="list-inline-item"><i class="fa fa-clock"></i> {{$order->getDatetime('ordered_at', 'H:i')}}</li>
                                                    </ul>
                                                    <ul class="list-inline float-right">
                                                        <li class="list-inline-item"><i class="fa fa-money-bill"></i> {{$helper->getCurrencyFormat($order->total_money)}}</li> 
                                                    </ul>
                                                    <div class="clearfix"></div>
                                                </div>
                                                
                                                
                                            </div>
                                        </div><!-- end card-header -->
                                    </a>
                                    <div id="order-{{$order->id}}" class="collapse">
                                        <div class="card-body">

                                            {{-- @if ($order && $order->details && count($order->details))


                                                <div class="order-list">
                                                    <ul class="list-unstyled">
                                                        @foreach ($order->details as $item)
                                                            <li class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                                                <div class="order">
                                                                    <div class="order-item">
                                                                        <div class="order-item-info">
                                                                            <h4><a href="{{$item->link}}">{{$item->product_name}}</a></h4>
                                                                        
                                                                            @if ($item->attributes && count($item->attributes))
                                                                                @foreach ($item->attributes as $attr)
                                                                                    <p>{{$attr->label??$attr->name}}: <strong>{{$attr->text}}</strong></p>
                                                                                @endforeach
                                                                            @endif
                                                                            <p class="order-item-price"><span>Giá : {{$item->getPriceFormat()}}</span> , Số lượng : {{$item->quantity}}</p>
                                                                        </div><!-- end order-item-info -->
                                
                                                                        <div class="order-item-img">
                                                                            <a href="{{$item->link}}"><img src="{{$item->image}}" class="img-fluid" alt="{{$item->product_name}}" /></a>
                                                                        </div><!-- end order-img -->
                                                                    </div><!-- end order-item -->
                                                                    
                                                                    <div class="total">
                                                                        <p>{{$item->quantity}} x {{$item->getPriceFormat()}} = <span>{{$item->getTotalFormat()}}</span></p>
                                                                    </div><!-- end total -->
                                                                </div><!-- end order-->
                                                            </li>
                                                        @endforeach

                                                    </ul>
                                                </div>
                                                
                                            @else
                                                <div class="text-center">
                                                    <h3>Không có sản phẩm nào trong giỏ hàng</h3>
                                                </div>
                                            @endif --}}
                                            <div class="order-name clearfix mb-2">
                                                <span class="float-left"><i class="fa fa-credit-card"></i> Thanh toán</span>
                                                <span class="float-right">{{$order->getPaymentMethodText()}}</span> 
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="buttons text-center ">
                                                <a href="{{route('client.orders.detail', ['id' => $order->id])}}" class="btn btn-success">Chi tiết</a>
                                                @if ($order->isTransferPayment() && $order->isStatus('pending-payment') )
                                                <a href="{{route('client.payments.check-order', ['order_id' => $order->id, 'contact' => $order->billing->email])}}" class=" btn btn-primary ">Thanh toán</a>
                                                @endif
                                                @if ($order->canCancel())
                                                    <a href="#" class="{{parse_classname('btn-cancel-order')}} btn btn-black" data-id="{{$order->id}}">Hủy</a>
                                                @endif
                                            </div>
                                            
                                            
                                        </div><!-- end card-body -->
                                    </div><!-- end collapse -->
                                </div><!-- end card-default -->
                            @endforeach
                            
                            <div class="list-pagination">
                                {{$orders->links($_template.'pagination')}}
                            </div>
                        @else
                            <div class="alert alert-info text-center">Không có đơn hàng</div>
                        @endif
                        

                    </div><!-- end container-fluid -->
                </div><!-- end order-history-page -->
            </section><!-- end page-wrapper -->
            

@endsection