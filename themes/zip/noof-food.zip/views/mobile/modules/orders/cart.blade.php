@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('mobile_');
    $pageHeader = $shopOptions->makeByPrefix('page_cover_');
    if($pageHeader->show){
        $show_page_cover = 1;
        
        $page_icon = 'fa fa-shopping-carT';
        
    }

@endphp
@extends($_layout.'master')
@section('page_title', 'Giỏ hàng')
@section('cover_title', 'Shop')
@include($_lib.'register-meta')

@section('content')


         
            <!--=================== PAGE-WRAPPER ================-->
            <section class="page-wrapper innerpage-section-padding">
                <div id="shopping-cart-page" >
                    <div class="container-fluid">
                        <div class="innerpage-heading text-center">
                            <h3>Giỏ hàng</h3>
                        </div><!-- end innerpage-heading -->
                        @if ($cart && $cart->details && count($cart->details))

                        <ul class="list-unstyled cart-list">
                            @foreach ($cart->details as $item)

                                <li class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                    <div class="cart-item">
        
                                        <div class="item-img">
                                            <a href="{{$item->link}}"><img src="{{$item->image}}" class="img-fluid" alt="{{$item->product_name}}" /></a>
                                        </div><!-- end item-img -->
                                        
                                        <div class="item-text dish-list-text info">
                                            <h4><a href="{{$item->link}}">{{$item->product_name}}</a></h4>
                                            
                                            @if ($item->attributes && count($item->attributes))
                                                @foreach ($item->attributes as $attr)
                                                    <p>{{$attr->label??$attr->name}}: <strong>{{$attr->text}}</strong></p>
                                                @endforeach
                                            @endif
                                            <h5>
                                                Số lượng: 
                                                <input class="form-control {{parse_classname('product-order-quantity', 'quantity', 'item-quantity')}} inp-quantity" type="number" name="quantity[{{$item->id}}]" id="qty{{$item->id}}" value="{{$item->quantity}}" data-item-id="{{$item->id}}" min="1" placeholder="1"> x {{$item->getPriceFormat()}}
                                            </h5>
                                        </div><!-- end item-text -->
                                        <h4 class="total">Thành tiền: <span class="{{parse_classname('item-total-price')}}">{{$item->getTotalFormat()}}</span></h4>
                                        
                                        <div class="item-close">
                                            <button class="btn {{parse_classname('remove-cart-item')}}" data-item-id="{{$item->id}}"><span><i class="fa fa-times-circle"></i></span></button>
                                        </div><!-- end item-close -->
                                    </div><!-- end cart-item -->
                                </li>
                            @endforeach

                        </ul>
                        
                        <div class="cart-info text-right">
                            <h4>Số SP : <span class="{{parse_classname('cart-quantity')}}">0</span></h4>
                            <h4>Tạm tính: <span class="{{parse_classname('cart-sub-total-ammount')}}">{{$helper->getCurrencyFormat($cart->sub_total)}}</span></h4>
                            <h4>Phí giao hàng: <span class="{{parse_classname('cart-shipping-fee')}}">{{$helper->getCurrencyFormat($cart->shipping_fee)}}</span></h4>
                            <h4>Thuế VAT: <span class="{{parse_classname('cart-tax-ammount')}}">{{$helper->getCurrencyFormat($cart->tax)}}</span></h4>
                            <h4><strong>Tổng thành tiền</strong>: <span class="{{parse_classname('cart-total-ammount')}}">{{$helper->getCurrencyFormat($cart->total_money)}}</span></h4>
                            
                            <a href="{{route('client.products')}}" class="btn btn-black">Tiếp tục mua hàng</a>
                            <a href="{{route("client.orders.checkout")}}" class="btn btn-primary">Thanh toán</a>
                        </div><!-- end cart-info -->
                        
                    @else
                        <div class="text-center">
                            <h3>Không có sản phẩm nào trong giỏ hàng</h3>
                        </div>
                    @endif
                    </div><!-- end container-fluid -->
                </div><!-- end shopping-cart-page -->
            </section><!-- end page-wrapper -->
            




@endsection