@php
    $general = $options->theme->general->makeByPrefix('mobile_');
    $page_ids = [
        1 => '',
        2 => 'bakery-homepage',
        3 => 'coffee-homepage'
    ];

    $page_id = $page_ids[$general->style]??$page_ids[1];
@endphp



<!doctype html>
<html lang="vi">
    
<head>
    
    @include($_lib.'head')

    </head>
	
    <body @if ($page_id) id="{{$page_id}}" @endif class="page-body">
        
        {!! $html->top->embeds !!}

        @yield('content')

        
        @include($_template.'js')
            
            
        {!! $html->bottom->embeds !!}
           
    
    </body>

</html>
