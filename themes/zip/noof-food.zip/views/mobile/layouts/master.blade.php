@php
    $general = $options->theme->general->makeByPrefix('mobile_');
    $header = $options->theme->header->makeByPrefix('mobile_');
    $footer = $options->theme->footer->makeByPrefix('mobile_');
    $page_ids = [
        1 => '',
        2 => 'bakery-homepage',
        3 => 'coffee-homepage'
    ];

    $page_id = $page_ids[$general->style]??$page_ids[1];
@endphp



<!doctype html>
<html lang="vi">
    
<head>
    
    @include($_lib.'head')

    </head>
	
    <body @if ($page_id) id="{{$page_id}}" @endif class="page-body">
        
        {!! $html->top->embeds !!}

        @include($_template.'loader')
        
        @include($_template.'nav')
        
        @include($_template.'shopping-cart')
        
        @include($_template.'user-profile')
        
        


        <div class="canvas">
            
            <div class="overlay-black"></div>
            
            @include($_template.'header')
            @php
                $showPageCover = $__env->yieldContent('show_page_cover', isset($show_page_cover) ? $show_page_cover : false);
            @endphp
        
            @if ($showPageCover && $showPageCover != 'false')
                @include($_template.'page-cover')
            @endif
    
            @yield('content')

            @include($_template.'footer')

		</div><!-- end canvas -->

        

        @include($_template.'js')
            
            
        {!! $html->bottom->embeds !!}
           
    
    </body>

</html>
