<!DOCTYPE html>
<html lang="vi">

<head>

    @include($_lib.'head')

</head>
<body>
    {!! $html->top->embeds !!}

    @include($_template.'advance-top')

    @include($_template.'header')

    @php
        $showPageHeader = $__env->yieldContent('show_page_header', isset($show_page_header) ? $show_page_header : false);
        $showBreadcrumb = $__env->yieldContent('show_breadcrumb', isset($show_breadcrumb) ? $show_breadcrumb : false);
    @endphp

    @if ($showPageHeader && $showPageHeader != 'false')
        @include($_template.'page-header')
    @elseif ($showBreadcrumb && $showBreadcrumb != 'false')
        @include($_template.'breadcrumb')
    @endif

    @yield('content')

    
    @include($_template.'footer')


    @include($_template.'js')
    
    
    {!! $html->bottom->embeds !!}
</body>

</html>