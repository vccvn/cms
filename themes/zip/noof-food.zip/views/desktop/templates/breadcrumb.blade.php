

    <div class="ps-breadcrumb">
        <div class="container">
            <ul class="breadcrumb">
                @if ($breakcrumbs = $helper->getBreakcrumbs())
                    @foreach ($breakcrumbs as $item)
                        <li @if ($loop->last) class="current active"@endif>
                            @if ($loop->last)
                            {{$item->text}}
                            @else
                            <a href="{{$item->url}}">{{$item->text}}</a>
                            @endif
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>
    </div>