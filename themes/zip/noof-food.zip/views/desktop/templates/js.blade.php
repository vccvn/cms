
        <!-- scrollToTop start here -->
		<a href="#" class="scrollToTop"><i class="icofont-swoosh-up"></i></a>
		<!-- scrollToTop ending here -->


    
    <script src="{{desktop_asset('js/jquery.js')}}"></script>
    <script src="{{desktop_asset('js/fontawesome.min.js')}}"></script>
    <script src="{{desktop_asset('js/waypoints.min.js')}}"></script>
    <script src="{{desktop_asset('js/bootstrap.min.js')}}"></script>
    <script src="{{desktop_asset('js/isotope.pkgd.min.js')}}"></script>
    <script src="{{desktop_asset('js/wow.min.js')}}"></script>
    <script src="{{desktop_asset('js/swiper.min.js')}}"></script>
    <script src="{{desktop_asset('js/progress.js')}}"></script>
    <script src="{{desktop_asset('js/tab.js')}}"></script>
    <script src="{{desktop_asset('js/lightcase.js')}}"></script>
    <script src="{{desktop_asset('js/jquery.countdown.min.js')}}"></script>

    

        
    <script>
        window.customCartInit = function () {
            App.cart.init({
                decimal: 0,
                templates: {
                    item: '<div class="cart-item" data-item-id="{$id}">'+
                        '<div class="cart-inner">'+
                            '<div class="cart-top">'+
                                '<div class="thumb">'+
                                    '<a href="{$link}"><img src="{$image}" alt="{$name}"></a>'+
                                '</div>'+
                                '<div class="content">'+
                                    '<a href="{$link}">{$name}</a>'+
                                '</div>'+
                                '<div class="remove-btn">'+
                                    '<a href="#" class="{{parse_classname('remove-cart-item')}}" data-item-id="{$id}"><i class="icofont-close"></i></a>'+
                                '</div>'+
                            '</div>'+
                            '{$attributes}'+
                            '<div class="cart-bottom">'+
                                '<div class="sing-price">{$price}</div>'+
                                '<div class="cart-plus-minus">{$quantity}'+
                                    // '<div class="dec qtybutton">-</div>'+
                                    // '<div class="dec qtybutton">-</div>'+
                                    // '<input type="text" name="quantity[{$id}]" id="qty-{$id}" value="{$quantity}" data-item-id="{$id}" min="1" placeholder="1" class="cart-plus-minus-box {{parse_classname('product-order-quantity', 'quantity', 'item-quantity')}}">'+
                                    // '<div class="inc qtybutton">+</div>'+
                                    // '<div class="inc qtybutton">+</div>'+
                                '</div>'+
                                '<div class="total-price">{$total_price}</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>',
                   
                    attribute: '<div class="sing-price"><strong class="{{parse_classname('attribute-label')}}">{$label}</strong>: <span class="{{parse_classname('attribute-value')}}">{$value}</span></div>'
                }
            });
        };
        window.authInit = function(){
            

            App.auth.init({
                urls: {
                    check: "{{route('client.account.check')}}"
                },
                templates: {
                    account_section: "<i class=\"fa fa-user\"></i> {$name}",
                    link: "<a class=\"dropdown-item\" href=\"{$link}\">{$text}</a>"
                }
            });
            App.auth.check(function(res){
                if(res.status){
                    // gs-account-links
                    
                    $('.gs-account-links').html('<a href="{{route('client.account')}}">'+res.data.name+'</a>'+
                    '<a href="{{route('client.account.logout')}}">Thoát</a>')
                }else{
                    $('.gs-account-links').html(
                        '<a href="{{route('client.account.login')}}">Đăng nhập</a>'+
                        '<a href="{{route('client.account.register')}}">Đăng ký</a>'
                    );
                }
            });
            

        };
    </script>
    @include($_lib.'js')
        
    <script src="{{desktop_asset('js/functions.js')}}"></script>

        
    
        

