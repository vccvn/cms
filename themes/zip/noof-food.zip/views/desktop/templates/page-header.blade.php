
@php
    $bg = $__env->yieldContent('page_header_background', isset($page_header_background)?$page_header_background:null);
@endphp

        
        <!-- Page Header Section Start Here -->
        <section class="page-header style-2" @if ($bg) style="background-image: url({{$bg}});" @endif>
            <div class="container">
                <div class="page-title text-center">
                    <h3>@yield('page_title', isset($page_title)?$page_title:'')</h3>
                    <ul class="breadcrumb">
                        @if ($breadcrumbs = $helper->getBreadcrumbs())
                            @foreach ($breadcrumbs as $item)
                                <li>
                                    @if ($loop->last)
                                        {{$item->text}}
                                    @else
                                        <a href="{{$item->url}}">
                                            @if($loop->first)
                                                <i class="fas fa-home"></i>
                                            @endif
                                            {{$item->text}}
                                        </a>
                                    @endif
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </div>
            </div>
        </section>
        <!-- Page Header Section Ending Here -->