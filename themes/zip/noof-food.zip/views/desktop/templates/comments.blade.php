<?php
$commentList = (isset($comments) && is_countable($comments)) ? $comments : [];
$refname = isset($ref)?$ref:null;
$refid = isset($ref_id)?$ref_id:0;
$link = isset($url)?$url:null;
$t = count($commentList);
if($user = $helper->getCurrentAccount()){
    $name = $user->name;
    $email = $user->email;
}else{
    $name = null;
    $email = null;
}
?>


    
    <div id="comments" class="comments">
        <h4 class="title-border">{{$t}} Bình luận</h4>
        @if ($t)
            @php
                $render = function($factory, $comments, $level = 0){
                    $html = '';
                    if(count($comments)){
                        $html .= '<ul class="comment-list">';
                            foreach ($comments as $key => $comment) {
                                $avatar = ($comment->author_id && $author = get_model_data('user', $comment->author_id)) ? get_user_avatar($author->avatar) : asset('images/default/avatar.png');

                                $html .= '<li class="comment">';
                                    $html .= '
                                    <div class="com-thumb">
                                        <img alt="" src="'.$avatar.'" srcset="'.$avatar.'" class="avatar avatar-90 photo" height="90" width="90">          
                                    </div>
                                    <div class="com-content">
                                        <div class="com-title">
                                            <div class="com-title-meta">
                                                <h6><a href="#" rel="external nofollow" class="url">'.$comment->author_name.'</a></h6>
                                                <span> '.$comment->dateFormat('d/m/Y - H:i').' </span>
                                            </div>
                                            '.($level > 3 ? '': '<span class="reply">
                                                <a rel="nofollow" class="comment-reply-link btn-reply-comment" href="javascript:void(0);" aria-label="Reply to '.htmlentities($comment->author_name).'" data-id="'.$comment->id.'" data-reply-for="'.htmlentities($comment->author_name).'"><i class="icofont-reply-all"></i>Trả lời</a>
                                            </span>').'
                                            
                                        </div>
                                        <p>'.$comment->htmlMessage().'</p>
                                        <div class="reply-btn"></div>
                                    </div>
                                    '.(($comment->publishChildren && count($comment->publishChildren)) ? $factory($factory, $comment->publishChildren, $level+1) : '').
                                '</li>';
                                
                            }
                        $html.='</ul>';
                    }
                    return $html;
                };
            @endphp
            {!! $render($render, $comments) !!}
            
        @endif
    </div>
    <div id="respond" class="comment-respond">
        <h4 class="title-border">Để lại ý kiến</h4>
        <p class="px-4">Email của bạn sẽ dược bão mật. Những trường có dấu * là bắt buộc </p>
        
        <div class="add-comment">
            <form method="post" action="{{route('client.comments.post')}}" data-ajax-url="{{route('client.comments.ajax')}}" class="{{parse_classname('comment-form')}}">
                @csrf
                <input type="hidden" name="parent_id" id="comment-reply-id" >
                <input type="hidden" name="ref" value="{{$refname}}">
                <input type="hidden" name="ref_id" value="{{$refid}}">
                <div class="comment-form">
                    <input type="text" id="comment_name" name="author_name" class=" inp " value="{{old('author_name', $name)}}" placeholder="Tên *" required>
                    <input type="text" id="comment_email" name="author_email" class="inp" value="{{old('author_email', $email)}}" placeholder="Email *">
                    <input type="text" id="comment_url" name="author_website" class="inp w-100p" value="{{old('author_website')}}" placeholder="Website">
                    <div class="crazy-message-content w-100p">
                        <textarea name="message" id="comment" class="comment-message-content message inp w-100p " placeholder="Viết nội dung bình luận..." required>{{old('message')}}</textarea>
                    </div>
                    <div class="w-100">
                        <button type="submit" class="food-btn"><span>Đăng bình luận</span></button>
                    </div>
                    

                </div>
            </form>
        </div>			
    </div>