<div class="header-top">
    <div class="container">
        <div class="top">
            {!! 
                $helper->getCustomMenu('topleft', 1, [
                    'class' => 'left'
                ],[
                    'props' => [
                        'menu_class' => '',
                        'item_class' => '',
                        'link_class' => ''
                    ]
                ])
            !!}
            {!! 
                $helper->getCustomMenu('topright', 1, [
                    'class' => 'right'
                ],[
                    'props' => [
                        'menu_class' => '',
                        'item_class' => '',
                        'link_class' => ''
                    ]
                ])
            !!}

        </div>
    </div>
</div>