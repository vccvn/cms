@php
    $footer = $options->theme->footer->makeByPrefix('desktop_');
@endphp

        {!! $html->desktop_footer->components !!}
