    
    <!-- Google Fonts -->	
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300italic,800italic,800,700italic,700,600italic,600,400italic,300%7CRoboto+Condensed:400,400i,700,700i%7CGreat+Vibes" rel="stylesheet"> 
    
    <!-- animate scss -->
    <link rel="stylesheet" href="{{desktop_asset('css/animate.css')}}">
    <!-- bootstarp css -->
    <link rel="stylesheet" href="{{desktop_asset('css/bootstrap.min.css')}}">
    <!-- icofont -->
    <link rel="stylesheet" href="{{desktop_asset('css/icofont.min.css')}}">
    
    <link rel="stylesheet" href="{{desktop_asset('css/all.min.css')}}">
    <!-- lightcase css -->
    <link rel="stylesheet" href="{{desktop_asset('css/lightcase.css')}}">
    <!-- swiper css -->
    <link rel="stylesheet" href="{{desktop_asset('css/swiper.min.css')}}">
    <!-- cusyom scss -->
    <link rel="stylesheet" href="{{desktop_asset('css/style.css')}}">
    <link rel="stylesheet" href="{{desktop_asset('css/custom.min.css')}}">

        
    
    <!-- Favicons -->
    @if ($shortcut_icon = $siteinfo->favicon($__env->yieldContent('favicon', desktop_asset('images/favicon.png'))))
        <link rel="shortcut icon" type="image/png" href="{{$shortcut_icon}}">
    @endif
    
    @if ($apple_icon = $siteinfo->apple_touch_icon($__env->yieldContent('apple-touch-icon')))
        <link rel="apple-touch-icon" href="{{$apple_icon}}">
    @endif
    