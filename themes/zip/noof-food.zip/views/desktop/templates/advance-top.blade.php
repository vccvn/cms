@php
    $header = $options->theme->header;
@endphp

<!-- preloader start here -->
<div class="preloader">
    <div class="preloader-inner">
        <div class="preloader-icon">
            <span></span>
            <span></span>
        </div>
    </div>
</div>
<!-- preloader ending here -->

<!-- search area -->
<div class="search-area">
    <div class="search-input">
        <div class="search-close">
            <span></span>
            <span></span>
        </div>
        <form method="GET" action="{{route('client.products')}}">
            <input type="text" name="text" placeholder="*Nhập từ khóa tìm kiếm">
            <button class="search-btn"><span class="serch-icon"><i class="icofont-search-2"></i></span></button>
        </form>
    </div>
</div>
<!-- search area -->

<!-- Mobile Menu Start Here -->
<div class="mobile-menu">
    <nav class="mobile-header">
        <div class="header-logo">
            <a href="{{route('home')}}">
                <img src="{{$header->mobile_logo($siteinfo->mobile_logo($header->logo($siteinfo->logo(desktop_asset('images/logo/01.png')))))}}" alt="{{$siteinfo->site_name}}">
            </a>
        </div>
        <div class="header-bar">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>
    <nav class="mobile-menu">
        <div class="mobile-menu-area">
            <div class="mobile-menu-area-inner">
                {!! 
                    $helper->getCustomMenu('primary', 3, [
                        'class' => ''
                    ],[
                        'menu_class' => '',
                        'item_class' => '',
                        'link_class' => ''
                    ])
                !!}
            </div>
        </div>
    </nav>
</div>
<!-- Mobile Menu Ending Here -->
