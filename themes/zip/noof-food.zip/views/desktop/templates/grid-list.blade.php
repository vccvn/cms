@php
    $c_class = isset($column_class)?$column_class: 'col-xl-3 col-md-6 col-12';
    $i_class = isset($item_class)?$item_class: '';
    $showDesc = isset($show_description)?$show_description:false;
    $style = isset($item_style)?$item_style:1;
    if($style == 2){
        $i_class .= ' style-2';
    }
    $name_length = (isset($name_langth) && is_numeric($name_langth) && $name_langth > 0) ? $name_langth : 40;
    $show_name = (isset($show_product_name) && $show_product_name);
    $total_price = 0;
@endphp

@if ($t = count($list))
    @foreach ($list as $item)
        

        <?php
        $hasOption = $item->hasOption();
        // $votes = $item->getReviewPoints();
        // $intVote = (int) $votes;
        // $max = $intVote < $votes ? $intVote + 1 : $intVote;
        $hasPromo = $item->hasPromo();
        $name =  $show_name ?  $item->name : str_limit($item->name, $name_length);


        $reviews = $item->getReviewData();
        $total_price += $item->getFinalPrice();
        ?>


        <div class="{{$c_class}}">
            <div class="product-item {{$i_class}}">
                <div class="product-thumb">
                    <a href="{{$u = $item->getViewUrl()}}">
                        <img src="{{$item->getFeatureImage()}}" alt="{{$item->name}}">
                    </a>
                    @if ($hasPromo)
                        <span class="price">-{{$item->getDownPercent()}}%</span>
                    @endif
                </div>
                <div class="product-content">

                    @if ($style == 2)
                        <div class="product-title">
                            <h6><a href="{{$u}}">{{$name}}</a></h6>
                            <div class="rating">
                                @for ($i = 0; $i < $reviews->rating_int; $i++)
                                    <i class="icofont-star"></i>
                                @endfor
                            </div>
                            <div class="product-desc">
                                <p>{{$item->getShortDesc(100)}}</p>
                            </div>        
                        </div>
                    @else
                        @if ($item->category)
                            <p>
                                <a href="{{$item->category->getViewUrl()}}">{{$item->category->name}}</a>
                            </p>
                        @endif
                        <h6><a href="{{$u}}">{{$name}}</a></h6>
                        <div class="rating">
                            @for ($i = 0; $i < $reviews->rating_int; $i++)
                                <i class="icofont-star"></i>
                            @endfor
                        </div>
                        <span class="price">{{$item->priceFormat('final')}}</span>
                        
                    @endif
                    
                </div>
            </div>
        </div>
    @endforeach
    @section('total_price', $total_price)
@endif
