@php
    $header = $options->theme->header;
@endphp

		<!-- desktop menu start here -->
		<header class="header-section">
			<div class="header-area">
                @if ($header->show_top_header)
                    @include($_template.'header-top')
                @endif
                <div class="header-bottom">
                    <div class="container">
                        <div class="primary-menu">
                            <div class="logo">
                                <a href="{{route('home')}}">
                                    <img src="{{$header->logo($siteinfo->logo(desktop_asset('images/logo/01.png')))}}" alt="{{$siteinfo->site_name}}">
                                </a>
                            </div>
                            <div class="main-area">
                                <div class="main-menu">
                                    {!! 
                                        $helper->getCustomMenu('primary', 3, [
                                            'class' => ''
                                        ],[
                                            'menu_class' => '',
                                            'item_class' => '',
                                            'link_class' => ''
                                        ])
                                    !!}
                                </div>
                                <div class="cart-search">
                                    <ul>
                                        <li class="search"><i class="icofont-search-2"></i></li>
                                        <li class="cart-area">
                                            <div class="cart-icon">
                                                <i class="icofont-cart-alt"></i>
                                            </div>
                                            <div class="count-item {{parse_classname('cart-quantity')}}">0</div>
                                            <div class="cart-content">
                                                <div class="cart-title">
                                                    <div class="add-item"><span class=" {{parse_classname('cart-quantity')}}">0</span> sản phẩm</div>
                                                    <div class="list-close"><a href="#">Đóng</a></div>
                                                </div>
                                                <div class="cart-scr scrollbar">
                                                    <div class="cart-con-item {{parse_classname('cart-items')}}">
                                                        <p class="text-center">Không có sản phẩm nào</p>
                                                    </div>
                                                </div>
                                                <div class="cart-scr-bottom">
                                                    <ul>

                                                        <li>
                                                            <div class="title">Tạm tính</div>
                                                            <div class="price {{parse_classname('cart-sub-total-ammount')}}">0</div>
                                                        </li>
                                                        {{-- 
                                                        <li>
                                                            <div class="title">Shipping</div>
                                                            <div class="price">Tk. 40.00</div>
                                                        </li>
                                                        <li>
                                                            <div class="title">Cart Total</div>
                                                            <div class="price">Tk. 1085.00</div>
                                                        </li>
                                                        --}}
                                                    </ul>
                                                    <a href="{{route('client.orders.cart')}}" class="food-btn"><span>Giỏ hàng</span></a>
                                                    
                                                    <a class="food-btn style-2 mt-0" href="{{route("client.orders.checkout")}}">
                                                        <span>Thanh toán</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
		</header>
		<!-- desktop menu ending here -->
        