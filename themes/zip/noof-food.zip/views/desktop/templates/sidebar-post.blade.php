<aside>

    {!!  $html->desktop_sidebar_post->components !!}

    {{-- 
    <div class="widget widget-archive">
        <div class="widget-header">
            <h5>FoodBuzz Archives</h5>
        </div>
        <ul class="widget-wrapper">
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>January</span><span>2019</span></a> </li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>February</span><span>2018</span></a></li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>March</span><span>2017</span></a></li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>April</span><span>2016</span></a></li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>June</span><span>2015</span></a></li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>July</span><span>2014</span></a></li>
            <li><a href="#" class="d-flex flex-wrap justify-content-between"><span><i class="icofont-double-right"></i>August</span><span>2013</span></a></li>
        </ul>
    </div> --}}

    {{-- <div class="widget widget-instagram">
        <div class="widget-header">
            <h5>FoodBuzz instagram</h5>
        </div>
        <ul class="widget-wrapper d-flex flex-wrap justify-content-center">
            <li><a href="#"><img src="assets/images/blog/08.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/02.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/03.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/04.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/05.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/06.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/07.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/08.jpg" alt="product"></a></li>
            <li><a href="#"><img src="assets/images/blog/09.jpg" alt="product"></a></li>
        </ul>
    </div> --}}



</aside>