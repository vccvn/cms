@php
    $a = isset($args) && is_array($args) ? $args : [];
    $c_class = isset($column_class)?$column_class: 'col-xl-3 col-md-6 col-12';
    $i_class = isset($item_class)?$item_class: '';
    $l_class = isset($list_class)?$list_class: '';
    $showDesc = isset($show_description)?$show_description:false;
    $style = isset($item_style)?$item_style:1;
    if($style == 2){
        $i_class .= ' style-2';
    }
    $name_length = (isset($name_langth) && is_numeric($name_langth) && $name_langth > 0) ? $name_langth : 40;
    $show_name = (isset($show_product_name) && $show_product_name);
@endphp

@if (count($products = $helper->getProducts($a)))
    <div class="row {{$l_class}}">
        @foreach ($products as $product)
            

            <?php
            $hasOption = $product->hasOption();
            // $votes = $product->getReviewPoints();
            // $intVote = (int) $votes;
            // $max = $intVote < $votes ? $intVote + 1 : $intVote;
            $hasPromo = $product->hasPromo();
            $name =  $show_name ?  $product->name : str_limit($product->name, $name_length);


            $reviews = $product->getReviewData();

            ?>


            <div class="{{$c_class}}">
                <div class="product-item {{$i_class}}">
                    <div class="product-thumb">
                        <a href="{{$u = $product->getViewUrl()}}">
                            <img src="{{$product->getThumbnail()}}" alt="{{$product->name}}">
                        </a>
                        <span class="price">{{(int) ($product->getFinalPrice() / 1000)}}k</span>
                    </div>
                    <div class="product-content">

                        @if ($style == 2)
                            <div class="product-title">
                                <h6><a href="{{$u}}">{{$name}}</a></h6>
                                <div class="rating">
                                    @for ($i = 0; $i < $reviews->rating_int; $i++)
                                        <i class="icofont-star"></i>
                                    @endfor
                                </div>
                                <div class="product-desc">
                                    <p>{{$product->getShortDesc(100)}}</p>
                                </div>        
                            </div>
                        @else
                            @if ($product->category)
                                <p>
                                    <a href="{{$product->category->getViewUrl()}}">{{$product->category->name}}</a>
                                </p>
                            @endif
                            <h6><a href="{{$u}}">{{$name}}</a></h6>
                            <div class="rating">
                                @for ($i = 0; $i < $reviews->rating_int; $i++)
                                    <i class="icofont-star"></i>
                                @endfor
                            </div>
                            
                        @endif
                        
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif
