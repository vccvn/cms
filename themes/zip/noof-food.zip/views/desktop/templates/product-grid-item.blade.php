<?php
$hasOption = $product->hasOption();
// $votes = $product->getReviewPoints();
// $intVote = (int) $votes;
// $max = $intVote < $votes ? $intVote + 1 : $intVote;
$hasPromo = $product->hasPromo();
$name =  (isset($show_product_name) && $show_product_name) ?  $product->name : str_limit(
    $product->name, (isset($name_langth) && is_numeric($name_langth) && $name_langth > 0) ? $name_langth : 40
);


$reviews = $product->getReviewData();

?>

<div class="col-xl-3 col-md-6 col-12">
    <div class="product-item">
        <div class="product-thumb">
            <a href="{{$u = $product->getViewUrl()}}">
                <img src="{{$product->getThumbnail()}}" alt="food-product">
            </a>
            <span class="price">{{(int) ($product->getFinalPrice() / 1000)}}k</span>
        </div>
        <div class="product-content">
            @if ($product->category)
                <p>
                    <a href="{{$product->category->getViewUrl()}}">{{$product->category->name}}</a>
                </p>
            @endif
            <h6><a href="{{$u}}">{{$name}}</a></h6>
            <div class="rating">
                @for ($i = 0; $i < $reviews->rating_int; $i++)
                    <i class="icofont-star"></i>
                @endfor
            </div>
        </div>
    </div>
</div>