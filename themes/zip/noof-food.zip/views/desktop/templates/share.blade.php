
<?php 
$url = urlencode(isset($link)?$link:route('home'));
$desc = urlencode(isset($description)?$description:'');
$img = urlencode(isset($image)?$image:'');
$tit = urlencode(isset($title)?$title:'');
?>
<div class="scocial-media">
    <a href="https://www.facebook.com/sharer/sharer.php?u={{$url}}&amp;src=sdkpreparse" class="facebook"><i class="icofont-facebook"></i></a>
    <a href="https://twitter.com/home?status={{$url}}{{$desc?' '.$desc:''}}" class="twitter"><i class="icofont-twitter"></i></a>
    <a href="https://www.linkedin.com/shareArticle?mini=true&url={{$url}}&title={{$tit}}&summary={{$desc}}&source=" class="linkedin"><i class="icofont-linkedin"></i></a>
    {{-- <a href="http://pinterest.com/pin/create/button/?url={{$url}}{{isset($desc)?'&description='.$desc:''}}" class="pinterest"><i class="icofont-pinterest"></i></a> --}}
</div>