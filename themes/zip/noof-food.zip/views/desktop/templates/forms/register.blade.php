
<form class="{{parse_classname('register-form')}}" action="{{route('client.account.post-register')}}" method="POST">
    @if ($next = old('next', $request->next))
        <input type="hidden" name="next" value="{{$next}}">
    @endif
    @php
        $registerForm = $html->getRegisterForm([
            'class' => 'form-control theme-size'
        ]);
    @endphp
    @csrf
    <div class="ps-form__content">
        <h5>Đăng ký tài khoản</h5>
        @if ($registerForm && $inputs = $registerForm->inputs())
            @foreach ($inputs as $input)
            <div class="form-group">
                {!! $input->type!="checkbox"?$input:$input->removeClass('form-control') !!}
                @if ($input->error)
                <div class="has-error error">{{$input->error}}</div>
                @endif
            </div>
            @endforeach
        @endif
        
        <div class="form-group submtit">
            <button class="food-btn bs-size style-2 w-100p"><span>Đăng ký</span></button>
        </div>
    </div>

    <div class="ps-form__footer">
        <p>Phương thức khác:</p>
        <ul class="ps-list--social">
            <li><a class="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a class="google" href="#"><i class="fab fa-google-plus"></i></a></li>
            <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a class="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
    </div>
</form>