<form class="{{parse_classname('login-form')}}" action="{{route('client.account.post-login')}}" method="POST">
    @if ($next = old('next', $request->next))
        <input type="hidden" name="next" value="{{$next}}">
    @endif
    @csrf

    <div class="ps-form__content">
        <h5>Đăng nhập tài khoản</h5>
        <div class="form-group">
            <input class="form-control theme-size" type="text" name="username" value="{{old('username')}}" placeholder="Tên đăng nhập hoặc email">
        </div>
        <div class="form-group form-forgot">
            <input class="form-control theme-size" type="password" name="password" placeholder="Mật khẫu"><a href="{{route('client.account.forgot')}}">Gặp vấn đề?</a>
        </div>
        
        @if ($error = session('error'))
            <div class="alert alert-danger text-center">
                {{$error}}
            </div>
        @endif
        <div class="form-group">
            <div class="ps-checkbox">
                <input type="checkbox" id="remember-me" name="remember" @if(old('remember')) checked @endif>
                <label for="remember-me">Nhớ đăng nhập</label>
            </div>
        </div>
        <div class="form-group submtit">
            <button class="food-btn bs-size style-2 w-100p"><span>Đăng nhập</span></button>
        </div>
    </div>
    <div class="ps-form__footer">
        <p>Phương thức khác:</p>
        <ul class="ps-list--social">
            <li><a class="facebook" href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a class="google" href="#"><i class="fab fa-google-plus"></i></a></li>
            <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a class="instagram" href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
    </div>
</form>