@php
$contacts = $options->theme->contacts;
    $show_page_header = 1;
    $page_title = $contacts->page_title('Liên hệ');
    $socials = $options->theme->socials;
    $list = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin'];
@endphp
@extends($_layout.'master')
@section('title', $page_title)

@if ($contacts->page_description)
    
@section('meta_description', $contacts->page_description)
    
@endif

@include($_lib.'register-meta')

@section('content')



         <!-- Contact Us Section Start Here -->
         <section class="contact-information padding-tb pb-xl-0">
            <div class="container">
                <div class="section-wrapper">
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <h5>Liên hệ</h5>
                            <div class="post-item">
                                <div class="post-content">
                                    <h6><i class="fa fa-map-marker"></i> Địa chỉ</h6>
                                    <p>{{$contacts->address($siteinfo->address)}}</p>
                                </div>
                            </div>
                            <div class="post-item">
                                <div class="post-content">
                                    <h6><i class="fa fa-phone"></i> Số diện thoại:</h6>
                                    <p><a href="tel:{{$phone = $contacts->phone_number($siteinfo->phone_number('094.578.6960'))}}">{{$phone}}</a></p>
                                </div>
                            </div>
                            <div class="post-item">
                                <div class="post-content">
                                    <h6> <i class="fa fa-envelope"></i>  Email : </h6>
                                    <p><a href="mailto:{{$email = $contacts->email($siteinfo->email('doanln.chinhlatoi@gmail.com'))}}">{{$email}}</a></p>
                                </div>
                            </div>
                            @foreach ($list as $item)
                                @if ($link = $socials->get($item))
                                <div class="post-item">
                                    <div class="post-content">
                                        <h6><i class="fab fa-{{$item}}"></i> {{ucfirst($item)}}: </h6>
                                        <p><a href="{{$link}}">{{$link}}</a></p>
                                    </div>
                                </div>
                                @endif
                            @endforeach

                            
                        </div>
                        <div class="col-lg-6 col-12">
                            <h5>Gửi liên hệ</h5>
                            
                            <form id="contactForm1" method="POST" action="{{route('client.contacts.send')}}" data-ajax-url="{{route('client.contacts.ajax-send')}}" class="{{parse_classname('contact-form')}} d-flex flex-wrap justify-content-between">
                                @csrf
                                <input id="name" name="name" type="text" required="" placeholder=" Họ và tên *">
                                <input id="email1" name="email" type="email" required="" placeholder="Địa chỉ e-mail *">
                                
                                <input type="text" name="subject" class="w-100" placeholder="Subject">
                                <textarea id="message1" name="message" placeholder="Message / Nội dung *"></textarea>
                                <button type="submit" class="food-btn style-2"><span>{{$contacts->button_text('Send message')}}</span></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Us Section Ending Here -->


        <!-- G-Map Section Start Here -->
        <div class="gmaps-section">
            <div class="map-area">
                {!! $contacts->map_code !!}
                
            </div>
        </div>
        <!-- G-Map Section Ending Here -->



@endsection