@php
    $postOptions = $options->theme->posts->makeByPrefix('desktop_');
    $pageHeader = $postOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
            if($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
        }
        
    }

@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')
    
        <!-- Blog Page Section Start Here -->
        <div class="blog-section blog-page padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    
                    <div class="row justify-content-center">
                        @if ($postOptions->list_type == 'fullwidth')
                        <div class="col-12">
                            <div class="alert alert-warning text-center">
                                Không có kết quả phù hợp
                            </div>
                        </div>
                        @else
                            
                            <div class="col-lg-8 col-12">
                                <div class="alert alert-warning text-center">
                                    Không có kết quả phù hợp
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-7 col-12">
                                @include($_template.'sidebar-post')
                            </div>
                        @endif
                    </div>
                        
                </div>
            </div>
        </div>
        
@endsection


