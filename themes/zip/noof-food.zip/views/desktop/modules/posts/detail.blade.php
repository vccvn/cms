@php
    $postOptions = $options->theme->posts->makeByPrefix('desktop_');
    $pageHeader = $postOptions->makeByPrefix('page_header_');
    
    $detailSettings = $postOptions->makeByPrefix('detail_');
    $next = $article->next();
    $previous = $article->previous();
    $url = $article->getViewUrl();
    $category = $article->getCategory();

    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->use_post_image){
                $page_header_background = $article->getFeatureImage();
            }
            elseif($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
            elseif($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
        }
        
    }

@endphp

@extends($_layout.'master')
@include($_lib.'register-meta')


@if (($article->contentType('gallery') || $dynamic->post_type == 'gallery') && $galleries = $article->gallery)
    @if (count($galleries))
        @section('gallery')
            <div class="post-gallery docly-carousel owl-carousel owl-theme" data-show="1" data-dots="true" data-autoplay="true" data-speed="500" data-nav="true" data-loop="true">
                @foreach ($galleries as $item)
                <div class="item">
                    <img class="img-responsive" src="{{$item->getUrl()}}">
                </div>
                @endforeach
            </div>
        @endsection
    @endif
@endif

@php
    $gallery = $__env->yieldContent('gallery');
    $content = '<div class="article-content">
                    '.$article->content.'
                </div>';
    
    if($gallery){
        $args = [];
        if($gallery){
            if(preg_match('/[^\{}]\{\$gallery\}[^\}]/i', $content)){
                $args['gallery'] = $gallery;
            }else{
                $content = $gallery.$content;
            }
        }
        $content = str_eval($article->content, $args);

    }
@endphp

@if ($next || $previous)
    @section('postnav')
        <div class="navigations-part">
            
            <div class="left">
                @if ($previous)
                    <a href="{{$pu = $previous->getViewUrl()}}" class="prev"><i class="icofont-double-left"></i>Bài trước</a>
                    <a href="#" class="title">{{$previous->sub('title', 128, '...')}}</a>
                @endif
                
            </div>
            <div class="right">
                @if ($next)
                    
                    <a href="{{$nu = $next->getViewUrl()}}" class="prev">Bài sau<i class="icofont-double-right"></i></a>
                    <a href="{{$nu}}" class="title">{{$next->sub('title', 128, '...')}}</a>
                    
                @endif
            </div>
        </div>

    @endsection

@endif

@section('content')



        <!-- Blog Page Section Start Here -->
        <div class="blog-section blog-page blog-single padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    <div class="row justify-content-center">
                        <div class="col-lg-8 col-12">
                            <article>
                                <div class="post-item">
                                    <div class="post-inner">
                                        @if ($article->contentType('embed') && $video = $article->getVideo())
                                            <div class="video-thumb">
                                                <img src="{{$article->getImage()}}" alt="video">
                                                <a href="{{$video->embed_url}}" data-rel="lightcase" class="video-icon"><i class="icofont-youtube-play"></i></a>
                                            </div>
                                        
                                        @else
                                            @if (!$detailSettings->hide_feature_image)
                                                
                                                <div class="post-thumb">
                                                    <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
                                                </div>
                                            @endif
                                        
                                        @endif
                                        <div class="post-content">
                                            <h4>{{$article->title}}</h4>
                                            <div class="meta-post">
                                                <ul>
                                                    <li>
                                                        <i class="icofont-calendar"></i>
                                                        <a href="#" class="date">{{$article->dateFormat('d/m/Y')}} </a>
                                                    </li>

                                                    <li>
                                                        <i class="icofont-ui-user"></i>
                                                        <a href="#" class="admin">{{$article->getAuthor()->name}}</a>
                                                    </li>
                                                    <li>
                                                        <i class="icofont-speech-comments"></i>
                                                        <a href="#" class="comment">{{$article->publishComments?count($article->publishComments):0}} Bình luận</a>
                                                    </li>
                                                </ul>
                                            </div>

                                                {!! $content !!}

                                            <div class="tags-section">
                                                <ul class="tags">
                                                    <li>Thẻ: </li>
                                                    @if ($article->tags && is_countable($article->tags) && count($article->tags))
                                                    
                                                        @foreach ($article->tags as $tag)
                                                            <li><a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a></li>
                                                        @endforeach
                                                    @endif
                                                    
                                                </ul>
                                                
                                                @include($_template.'share', [
                                                    'link' => $article->getViewUrl(),
                                                    'title' => $article->title,
                                                    'description' => $article->getShortDesc(300),
                                                    'image' => $article->getFeatureImage(),
                                                    
                                                ])
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @yield('postnav')

                                {{-- <div class="authors">
                                    <div class="author-thumb">
                                        <a href="#"><img src="assets/images/chef/author/01.png" alt="author"></a>
                                    </div>
                                    <div class="author-content">
                                        <h6>LabArtisan</h6>
                                        <p>Data release Friday large ponted to better than expcted pickup in the euroz yieldsrose tolate Thursd and the euro edged up slghtly toY after the Grman recent political uncertainty in Germany has so far</p>
                                        <div class="scocial-media">
                                            <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
                                            <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
                                            <a href="#" class="linkedin"><i class="icofont-linkedin"></i></a>
                                            <a href="#" class="vimeo"><i class="icofont-vimeo"></i></a>
                                        </div>
                                    </div>
                                </div> --}}

                                @if ($detailSettings->show_comment_form)
                                    
                                @include($_template.'comments',[
                                    'comments' => $article->publishComments,
                                    'ref' => $article->type,
                                    'ref_id' => $article->id,
                                    'url' => $article->getViewUrl()
                                ])
                                
                                @endif
                            
                            </article>
                        </div>
                        <div class="col-lg-4 col-md-7 col-12">
                            @include($_template.'sidebar-post')
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Blog Page Section Ending Here -->





@endsection


