
<div class="col-lg-8 col-12">
    <article>
        <div class="row justify-content-center">
            @if (count($pages))
                @foreach ($pages as $page)
                
                <div class="col-sm-6 col-12">
                    <div class="post-item">
                        <div class="post-item-inner">
                            <div class="post-thumb">
                                <a href="{{$u = $page->getViewUrl()}}"><img src="{{$page->getFeatureImage()}}" alt="{{$page->title}}"></a>
                            </div>
                            <div class="post-content">
                                <h5><a class="" href="{{$u}}">{{$page->sub('title', 64, '...')}}</a></h5>
                                <div class="author-date">
                                    <a href="{{$u}}" class="date"><i class="icofont-calendar"></i>{{$page->dateFormat('d/m/Y')}}</a>
                                    @if ($page->author)
                                    <a href="#" class="admin"><i class="icofont-ui-user"></i>{{$page->author->name}}</a>    
                                    @endif
                                    
                                </div>
                                <p>{{$page->getShortDesc(120)}}</p>
                                <div class="post-footer">
                                    <a href="{{$u}}" class="text-btn">Chi tiết<i class="icofont-double-right"></i></a>
                                    <a href="{{$u}}#comments" class="comments"><i class="icofont-comment"></i><span>{{$page->comments_count??0}}</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach

                <div class="col-12">
                    {{$pages->links($_template.'pagination')}}
                </div>
            @else
                <div class="col-12">
                    <div class="alert alert-warning text-center">
                        Không có kết quả phù hợp
                    </div>
                </div>
            @endif
        </div>
    </article>
</div>
<div class="col-lg-4 col-md-7 col-12">
    <aside>

        {!!  $html->desktop_sidebar_page->components !!}

    </aside>
</div>