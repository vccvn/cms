@php
    $pageOptions = $options->theme->pages->makeByPrefix('desktop_');
    $pageHeader = $pageOptions->makeByPrefix('page_header_');
    
    $detailSettings = $pageOptions->makeByPrefix('detail_');
    
    $layout_type = $detailSettings->layout_type;

    $url = $article->getViewUrl();
    
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->use_feature_image){
                $page_header_background = $article->getFeatureImage();
            }
            elseif($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
        }
        
    }

@endphp

@extends($_layout.'master')
@include($_lib.'register-meta')

@section('detail')
<article>
    <div class="section-wrapper">
        <div class="post-item">
            <div class="post-inner">
                @if (!$detailSettings->hide_feature_image)
                    
                    <div class="post-thumb">
                        <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
                    </div>
                @endif
            
                <div class="post-content">
                    @if (!$detailSettings->hide_title)
                        <h4 class="{{$detailSettings->title_align_center?'text-center':''}}">{{$article->title}}</h4>
                    @endif
                    @if (!$detailSettings->hide_author)
                        
                    <div class="meta-post">
                        <ul>
                            <li>
                                <i class="icofont-calendar"></i>
                                <a href="#" class="date">{{$article->dateFormat('d/m/Y')}} </a>
                            </li>
                            @if ($article->author)
                                
                            <li>
                                <i class="icofont-ui-user"></i>
                                <a href="#" class="admin">{{$article->author->name}}</a>
                            </li>
                            
                            @endif
                            <li>
                                <i class="icofont-speech-comments"></i>
                                <a href="#" class="comment">{{$article->publishComments?count($article->publishComments):0}} Bình luận</a>
                            </li>
                        </ul>
                    </div>

                    
                    @endif
                    

                    <div class="article-content">
                        {!! $article->content !!}
                    </div>

                    <div class="tags-section">
                        <ul class="tags">
                            <li>Thẻ: </li>
                            @if ($article->tags && is_countable($article->tags) && count($article->tags))
                            
                                @foreach ($article->tags as $tag)
                                    <li><a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a></li>
                                @endforeach
                            @endif
                            
                        </ul>
                        
                        @include($_template.'share', [
                            'link' => $article->getViewUrl(),
                            'title' => $article->title,
                            'description' => $article->getShortDesc(300),
                            'image' => $article->getFeatureImage(),
                            
                        ])
                    </div>
                </div>
            </div>
        </div>

        @if ($detailSettings->show_comment_form)
            
        @include($_template.'comments',[
            'comments' => $article->publishComments,
            'ref' => $article->type,
            'ref_id' => $article->id,
            'url' => $article->getViewUrl()
        ])
        
        @endif
    </div>

</article>
@endsection

@section('content')



        <!-- Blog Page Section Start Here -->
        <div class="blog-section blog-page blog-single padding-tb">
            @if ($layout_type == 'fullwidth')
                @yield('detail')
            @elseif($layout_type == 'container')
            <div class="container">
                @yield('detail')
            </div>
            @else
            <div class="container">
                @yield('detail')
            </div>
            @endif
            
        </div>
        <!-- Blog Page Section Ending Here -->





@endsection


