@php
    $pageOptions = $options->theme->pages->makeByPrefix('desktop_');
    $pageHeader = $pageOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
            if($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
        }
        
    }

@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')
    
        <!-- Blog Page Section Start Here -->
        <div class="blog-section blog-page padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    
                    <div class="row justify-content-center">
                        @if ($pageOptions->list_type == 'fullwidth')
                            @include($_current.'fullwidth')
                        @else
                            @include($_current.'sidebar')
                        @endif
                    </div>
                        
                </div>
            </div>
        </div>
        
@endsection


