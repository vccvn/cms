<div class="ps-page__header">
    <h1>{{$page_title?$page_title:'Tin bài'}}</h1>
    @include($_template.'breakcrumb-2')
</div>
