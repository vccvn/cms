@php
    $shopOptions = $options->theme->shop->makeByPrefix('desktop_');
    $pageHeader = $shopOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
            if($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
        }
        
    }

    
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')


        <!-- Shop Page Section Start Here -->
		<div class="shop-page single padding-tb bg-fa">
            <div class="container">
                <div class="section-wrapper">
                    <div class="text-center alert alert-warning">
                        Danh sách trống
                    </div>
                </div>
            </div>
        </div>
        <!-- Shop Page Section Ending Here -->




@endsection


