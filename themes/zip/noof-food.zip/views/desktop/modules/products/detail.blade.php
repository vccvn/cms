@php

    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('desktop_');
    $pageHeader = $shopOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->use_product_image){
                $page_header_background = $product->getFeatureImage();
            }
            elseif($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
            elseif($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
        }
        
    }
    $hasOption = $product->hasOption();
    $hasPromo = $product->hasPromo();
    $reviews = $product->getReviewData();
    $votes = $product->getReviewPoints();
    $intVote = (int) $votes;
    $max = $intVote < $votes ? $intVote + 1 : $intVote;
    $u = $product->getViewUrl();
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')

@section('content')


		<!-- Popular Home Chef Section Start Here -->
		<div class="shop-page single padding-tb pb-0 {{parse_classname('product-detail')}}">
            <div class="container">
                <div class="section-wrapper {{parse_classname('product-detail-info', 'product-detail-info-'.$product->id)}}" id="product-detail-{{$product->id}}" data-id="{{$product->id}}">
                    <div class="row justify-content-center">
                        <div class="{{$allow_place_order?'col-xl-8':''}} col-12">
                            <article>
                                <div class="shop-single">
                                    <div class="row justify-content-center">
                                        <div class="col-md-6 col-12">
                                            <div class="swiper-container gallery-top">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="shop-item">
                                                            <div class="shop-thumb">
                                                                <img src="{{$thumb = $product->getFeatureImage()}}" alt="{{$product->name}}">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @if (count($product->gallery))
                                                        @foreach ($product->gallery as $item)
                                                            <div class="swiper-slide">
                                                                <div class="shop-item">
                                                                    <div class="shop-thumb">
                                                                        <img src="{{$item->getUrl()}}" alt="{{$product->name}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="swiper-container gallery-thumbs">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="shop-item">
                                                            <div class="shop-thumb">
                                                                <img src="{{$thumb}}" alt="{{$product->name}}">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @if (count($product->gallery))
                                                        @foreach ($product->gallery as $item)
                                                            <div class="swiper-slide">
                                                                <div class="shop-item">
                                                                    <div class="shop-thumb">
                                                                        <img src="{{$item->getUrl()}}" alt="{{$product->name}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="shop-single-content">
                                                <div class="title">
                                                    <h5><a href="{{$product->getViewUrl()}}">{{$product->name}}</a></h5>
                                                    @if ($product->category && $tree = $product->category->getTree())
                                                        <p class="p-food-group">
                                                            <span>Danh mục :</span>
                                                            @foreach ($tree as $cate)
                                                            <a href="{{$cate->getViewUrl()}}">{{$cate->name}}</a>{{$loop->last?'':','}} 
                                                            @endforeach                                                
                                                        </p>
                                                    @endif
                                                    @if ($reviews->total)
                                                    <div class="rating">
                                                        @for ($i = 1; $i < 6; $i++)
                                                            @if ($i <= $intVote)
                                                                <i class="fa fa-star"></i>
        
                                                            @elseif($i > $intVote && $i == $max)
                                                                <i class="fas fa-star-half-alt"></i>
                                                            @else
                                                                <i class="fas fa-star-alt"></i>
                                                            @endif
                                                        @endfor
                                                        <span>({{$reviews->total}} Đánh giá)</span>
                                                    </div>
                                                    
                                                    @endif
                                                </div>
                                                <div class="desc">
                                                    <p>{{$product->getShortDesc(200)}}</p>
                                                    <ul>
                                                        {!! ($desc = nl2array(strip_tags($product->feature_description)))? '<li>' . implode('</li><li>', $desc ) . '</li>' :'' !!}
                                                    </ul>
                                                    @if ($product->code)
                                                        
                                                    <div class="quyality">
                                                        <p><span>SKU</span> : {{$product->code}}</p>
                                                    </div>
                                                    
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </div>
                        @if ($allow_place_order)
                            
                        <div class="col-xl-4 col-md-5 col-12">
                            <form  action="{{route('client.orders.add-to-cart')}}" method="post" class="{{parse_classname('product-order-form')}}">
                                @csrf
                                <input type="hidden" name="product_id" value="{{$product->id}}" class="{{parse_classname('product-order-id')}}">
                                <aside>
                                
                                    <div class="popular-chef-widget">
                                        <div class="food-quyality">
                                            <div class="section-header">
                                                <p>
                                                    Đặt hàng
                                                    {{-- Availability: <span>{{$product->total}} in Stock</span> --}}
                                                </p>
                                            </div>
                                            <div class="section-wrapper">
                                                @if ($product->affiliates && count($product->affiliates))
                                    
                                                    <div class="ps-product__desc">
                                                        <div class="ps-list--dot">
                                                            Sản phẩm hiện có trên: 
                                                        </div>
                                                        <div class="affiliates product-affiliates">
                                                            <div class="row">
                                                                @php
                                                                    $affiliateOptions = $options->theme->shop->makeByPrefix('affiliate_');
                                                                @endphp
                                                                @foreach ($product->affiliates as $affiliate)
                                                                    @php
                                                                        if($mas = nooffood_affiliate_settings($affiliate->id)){
                                                                            $a = $mas;
                                                                        }else{
                                                                            $a = $affiliateOptions;
                                                                        }
                                                                        $color = $a->color;
                                                                        $border_color = $a->border_color($a->color);
                                                                        $logo_background_color = $a->logo_background_color;
                                                                        $logo_text_color = $a->text_color_color($logo_background_color?'#fff':'');
                                                                        $price_background_color = $a->price_background_color;
                                                                        $price_text_color = $a->price_text_color($color);
                                                                    @endphp
                                                                    <div class="col-sm-6 ">
                                                                        <a href="{{$affiliate->url}}">
                                                                            <div class="row affiliate-item product-affiliate-item" style="{{$border_color? 'border-color: ' . $border_color . '; ' : ''}}">
                                                                                <div class="col-5 affiliate-logo" style="{{$logo_background_color?'background-color: ' . $logo_background_color . '; ' : ''}}{{$logo_text_color?'color: ' . $logo_text_color : ''}}">
                                                                                    <img src="{{$affiliate->logo_url}}" alt="{{$affiliate->name}}">
                                                                                </div>
                                                                                <div class="col-7 affiliate-price" style="{{$price_background_color ? 'background-color: ' . $price_background_color . '; ' : ''}}{{$price_text_color?'color: ' . $price_text_color : ''}}">
                                                                                    {{$affiliate->priceFormat()}}
                                                                                </div>
                                                                            </div>
                                                                        </a>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                @endif

                                                <h5><span class="{{parse_classname('product-price')}}">{{$product->priceFormat('final')}}</span></h5>
                                                {!!
                                                    $product->attributesToHtml([
                                                        'section_class' => '',
                                                        'attribute_class' => '',
                                                        'attribute_name_class' => '',
                                                        'value_list_class' => '',
                                                        'value_item_class' => '',
                                                        'select_class' => '',
                                                        'image_class' => '',
                                                        'value_text_class' => '',
                                                        'radio_class' => '',
                                                        'value_label_class' => ''
                                                    ])
                                                !!}
                                                <p>Số lượng</p>
                                                <label>
                                                    <input class="{{parse_classname('product-order-quantity', 'quantity')}} inp-quantity" type="text" name="quantity" placeholder="1" value="1">
                                                </label>
                                                
                                                <button class="food-btn style-2"><span>Thêm giỏ hàng</span></button>
                                                <ul>
                                                    <li><a href="#"><i class="icofont-heart-alt"></i>Wishlist</a></li>
                                                    <li><a href="#"><i class="icofont-drag2"></i>Compare</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                
                                </aside>
                            </form>
                        </div>
                        
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <!-- Popular Home Chef Section Ending Here -->



        
        <!-- Review Section Start Here -->
        <div class="review single padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    <div class="related">
                        <ul class="tab-bar">
                            <li class="tablinks" id="defaultOpen" onclick="openCity(event, 'one')">
                                <span>Cùng danh mục</span>
                            </li>
                            <li class="tablinks" onclick="openCity(event, 'two')">
                                <span>Chi tiết sản phẩm</span>
                            </li>
                            <li class="tablinks" onclick="openCity(event, 'three')">
                                <span>thông tin bổ xung</span>
                            </li>
                            <li class="tablinks" onclick="openCity(event, 'four')">
                                <span>Đánh giá</span>
                            </li>
                        </ul>
                        <div id="one" class="tabcontent">
                            <div class="products">
                                @if ($t = count($list = $product->getRelated(3)))
                                <div class="section-wrapper">
                                    <div class="row justify-content-center align-items-center">
                                        @include($_template.'grid-list')
                                        <div class="col-xl-3 col-md-6 col-12">
                                            <div class="p-food-item">
                                                <div class="p-food-inner">
                                                    <div class="food-quyality">
                                                        <div class="section-header">
                                                            <p>Availability: <span> in Stock</span></p>
                                                        </div>
                                                        <div class="section-wrapper">
                                                            <h5>{{get_currency_format($__env->yieldContent('total_price'))}}</h5>
                                                            <p>{{$t}} Sản phẩm</p>
                                                            <a href="#" class="food-btn"><span>Ve26 trang chủ</span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>

                        <div id="two" class="tabcontent">
                            <div class="Description post-content">
                                {!! $product->detail !!}
                            </div>
                        </div>

                        <div id="three" class="tabcontent">
                            <div class="spe-shop">
                                <div class="tec-spe">
                                    @if ($attributes = $product->getProductAttributes())
                                        <ul>
                                            @foreach ($attributes as $attr)
                                                <li>
                                                    <div class="left">{{$attr->label?$attr->label:$attr->name}}</div>
                                                    <div class="right">
                                                        @foreach ($attr->values as $val)
                                                            {{$loop->index?', ':''}}{{$val->text}}
                                                        @endforeach
                                                    </div>
                                                </li>
                                            @endforeach
                                        </ul>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div id="four" class="tabcontent">
                            <div class="section-wrapper">
                                <div class="review">
                                    <ul class="content">
                                        @if (count($product->reviews))
                                            @foreach ($product->reviews as $review)
                                                
                                                <li>
                                                    <div class="post-thumb">
                                                        <img src="{{$review->getAvatar()}}" alt="{{$review->review_name}}">
                                                    </div>
                                                    <div class="post-content">
                                                        <div class="content-area">
                                                            <div class="entry-meta">
                                                                <div class="posted-on">
                                                                    <a href="#">{{$review->review_name}}</a>
                                                                    <p>Thời gian: {{$review->dateFormat('H:i')}} - ngày {{$review->dateFormat('d/m/Y')}}</p>
                                                                </div>
                                                                <div class="rating">
                                                                    @for ($i = 0; $i < $review->rating; $i++)
                                                                        <i class="icofont-star"></i>
                                                                    @endfor
                                                                </div>
                                                            </div>
                                                            <div class="entry-content">
                                                                <p>{{$review->comment}}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                
                                            @endforeach
                                        @endif
                                    </ul>
                                    <div class="client-review">
                                        <div class="review-form">
                                            <div class="review-title">
                                                <h5>Gửi đánh giá</h5>
                                            </div>
                                            <form class="{{parse_classname('product-review-form')}}" action="{{route('client.products.review')}}" method="post">
                                                @csrf

                                                <input type="hidden" name="product_id" value="{{$product->id}}">
                                                

                                                <div class="row">
                                                    <div class="col-md-4 col-12">
                                                        <input class="{{parse_classname('auto-fill', 'fill-name')}}" type="text" name="name" placeholder="Họ tên">
                                                    </div>
                                                    <div class="col-md-4 col-12">
                                                        <input class="{{parse_classname('auto-fill', 'fill-email')}}" type="email" name="email" placeholder="Email">
                                                    </div>
                                                    <div class="col-md-4 col-12">
                                                        <div class="ratings">
                                                            <span class="rating-title">Đánh giá : </span>
                                                            <select class="ps-rating" data-read-only="false" name="rating">
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-12">
                                                        <textarea class="form-control" rows="6" placeholder="Viết đánh giá của bạn..." name="comment"></textarea>
                                                    </div>
                                                    <div class="col-12">
                                                        <button type="submit" class="food-btn style-2"><span>Gửi đánh giá</span></button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Review Section Ending Here -->

@endsection


@section('css')
    <link rel="stylesheet" href="{{desktop_asset('plugins/jquery-bar-rating/themes/fontawesome-stars.css')}}">
@endsection
@section('js')
    <script src="{{desktop_asset('plugins/jquery-bar-rating/jquery.barrating.min.js')}}"></script>
    <script>
        $(function() {
            $('.ps-rating').barrating({
                theme: 'fontawesome-stars'
            });
        });
    </script>
@endsection