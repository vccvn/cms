@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('desktop_');
    $pageHeader = $shopOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom'){
            if($pageHeader->background){
                $page_header_background = $pageHeader->background;
            }
            if($pageHeader->use_category_image && isset($category) && $category && $category->feature_image){
                $page_header_background = $category->getFeatureImage();
            }
        }
        
    }

    $listActive = $request->tab == 'list';
    $gridActive = !$listActive;
    
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')


        <!-- Shop Page Section Start Here -->
		<div class="shop-page single padding-tb bg-fa">
            <div class="container">
                <div class="section-wrapper">
                    <div class="shop-title d-flex flex-wrap justify-content-between">
                        <p>
                            @if ($t = count($products))
                                Hiển thị từ <strong>{{$products->from()}}</strong> đến <strong>{{$products->to()}}</strong> trên tổng số <strong>{{$products->total()}}</strong> sản phẩm
                            @else
                                Không tìm thấy sản phẩm nào
                            @endif
                        </p>
                        <div class="product-view-mode">
                            <a @if ($gridActive) class="active" @endif data-target="grid"><i class="icofont-ghost"></i></a>
                            <a @if ($listActive) class="active" @endif data-target="list"><i class="icofont-listing-box"></i></a>
                        </div>
                    </div>

                    @if ($t)
                        
                    <div class="shop-product-wrap {{$listActive?'list':'grid'}} row">

                        
                        @foreach ($products as $product)
                            @php
                                $hasOption = $product->hasOption();
                                $votes = $product->getReviewPoints();
                                $intVote = (int) $votes;
                                $max = $intVote < $votes ? $intVote + 1 : $intVote;
                                $hasPromo = $product->hasPromo();
                                $name = str_limit($product->name, 40);


                                $reviews = $product->getReviewData();
                            @endphp
                            <div class="col-xl-3 col-md-6 col-12">
                                <div class="product-item">
                                    <div class="product-thumb">
                                        <a href="{{$u = $product->getViewUrl()}}">
                                            <img src="{{$img = $product->getThumbnail()}}" alt="{{$product->name}}">
                                        </a>
                                        
                                        @if ($hasPromo)
                                            
                                            <span class="price">-{{$product->getDownPercent()}}%</span>
                                        
                                        @endif
                                        @if ($allow_place_order)
                                            
                                        <div class="product-action-link">
                                            <a href="{{$img}}" data-rel="lightcase"><i class="icofont-eye"></i></a>
                                            <a href="{{$hasOption?$u:'javascript:void(0)'}}" class="{{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}"><i class="icofont-cart-alt"></i></a>
                                            <a href="#"><i class="icofont-heart-alt"></i></a>
                                            
                                        </div>
                                        
                                        @endif
                                    </div>
                                    <div class="product-content">
                                        <div class="product-title">
                                            @if ($product->category)
                                                <span class="cat-name"><a href="{{$product->category->getViewUrl()}}">{{$product->category->name}}</a></span>
                                            @endif
                                            
                                            
                                            <h6><a href="{{$u}}">{{$name}}</a></h6>
                                            <span class="price">
                                                {{$product->priceFormat('final')}}
                                            </span>
                                            <div class="rating">
                                                @for ($i = 1; $i < 6; $i++)
                                                    @if ($i <= $intVote)
                                                        <i class="fa fa-star"></i>

                                                    @elseif($i > $intVote && $i == $max)
                                                        <i class="fas fa-star-half-alt"></i>
                                                    @else
                                                        <i class="fas fa-star-alt"></i>
                                                    @endif
                                                @endfor
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-list-item">
                                    <div class="product-thumb">
                                        <a href="{{$u}}">
                                            <img src="{{$product->getThumbnail()}}" alt="{{$product->name}}">
                                        </a>
                                        @if ($allow_place_order)
                                            
                                        <div class="product-action-link">
                                            <a href="{{$img}}" data-rel="lightcase"><i class="icofont-eye"></i></a>
                                            <a href="{{$hasOption?$u:'javascript:void(0)'}}" class="{{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}"><i class="icofont-cart-alt"></i></a>
                                            <a href="#"><i class="icofont-heart-alt"></i></a>
                                            
                                        </div>
                                        
                                        @endif
                                    </div>
                                    <div class="product-content">
                                        <div class="product-title">
                                            @if ($product->category)
                                                <span class="cat-name"><a href="{{$product->category->getViewUrl()}}">{{$product->category->name}}</a></span>
                                            @endif
                                            <h6><a href="{{$u}}">{{$name}}</a></h6>
                                            <span class="price">
                                                {{$product->priceFormat('final')}}
                                            </span>
                                            <div class="rating">
                                                @for ($i = 1; $i < 6; $i++)
                                                    @if ($i <= $intVote)
                                                        <i class="fa fa-star"></i>

                                                    @elseif($i > $intVote && $i == $max)
                                                        <i class="fas fa-star-half-alt"></i>
                                                    @else
                                                        <i class="fas fa-star-alt"></i>
                                                    @endif
                                                @endfor
                                            </div>
                                            <p>{{$product->getShortDesc(300)}}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                        
                        @endforeach


                    </div>
                    <div class="pagination-group">
                        <div class="grid-pagination">
                            {{$products->links($_template.'pagination', ['tab' => 'grid'])}}
                        </div>
                        
                        
                        <div class="list-pagination">
                            {{$products->links($_template.'pagination', ['tab' => 'list'])}}
                        </div>
                        
                    </div>
                    
                    @else
                        <div class="text-center alert alert-warning">
                            Danh sách trống
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <!-- Shop Page Section Ending Here -->




@endsection


