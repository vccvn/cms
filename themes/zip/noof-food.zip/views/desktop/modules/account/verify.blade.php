@extends($_layout.'master')
@section('title', 'Xác minh tài khoản')
@section('page_type', 'my-account')

@section('content')

<!-- buzz soon section start here -->
<section class="buzz-section d-flex align-items-center">
    <div class="container">
        <div class="ps-form--account ps-tab-root">
            <ul class="ps-tab-list">
                <li class="active"><a href="#forgot">Gửi Email xác minh tài khoản</a></li>
                
            </ul>
            <div class="ps-tabs">
                <div class="ps-tab active" id="forgot">
                    <form method="POST" action="{{route('client.account.verify.send-email')}}" class="{{parse_classname('verify-form')}}" >
                        @if ($next = old('next', $request->next))
                            <input type="hidden" name="next" value="{{$next}}">
                        @endif
                        @csrf
                    
                        <div class="ps-form__content">
                            <h5>Tạo mật khẩu mới</h5>
                            <div class="form-group">
                                <input class="form-control theme-size" type="email" name="email" placeholder="Nhập Email của bạn">
                            </div>
                            @if ($error = session('error'))
                                <div class="alert alert-danger text-center">
                                    {{$error}}
                                </div>
                            @endif

                            @if ($error = session('error')??$errors->first('email'))
                                <div class="alert alert-danger text-center">
                                    {{$error}}
                                </div>
                            @endif
                            <div class="form-group submtit">
                                <button class="food-btn style-2 w-100p bs-size"><span>Gửi</span></button>
                            </div>
                        </div>
                        
                        <div class="ps-form__footer">
                            <p>
                                <a href="{{route('client.account.login')}}">Đăng nhập</a>
                                | 
                                <a href="{{route('client.account.register')}}">Đăng ký</a>
                            </p>
                            
                        </div>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
</section>



@endsection