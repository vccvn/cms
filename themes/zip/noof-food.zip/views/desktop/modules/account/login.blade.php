@extends($_layout.'master')
@section('title', 'Đăng nhập')
@section('page_type', 'my-account')

@section('content')



		<!-- buzz soon section start here -->
        <section class="buzz-section d-flex align-items-center">
            <div class="container">
                <div class="ps-form--account ps-tab-root">
                    <ul class="ps-tab-list">
                        <li class="active"><a href="#sign-in">Đăng nhập</a></li>
                        <li><a href="#register">Đăng ký</a></li>
                    </ul>
                    <div class="ps-tabs">
                        <div class="ps-tab active" id="sign-in">
                            @include($_template.'forms.login')
        
                        </div>
                        <div class="ps-tab" id="register">
                            @include($_template.'forms.register')
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- buzz soon section ending here -->


@endsection