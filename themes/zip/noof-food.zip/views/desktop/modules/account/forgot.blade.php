@extends($_layout.'master')
@section('title', 'Quên mật khẩu')
@section('page_type', 'my-account')

@section('content')


		<!-- buzz soon section start here -->
        <section class="buzz-section d-flex align-items-center">
            <div class="container">
                <div class="ps-form--account ps-tab-root">
                    <ul class="ps-tab-list">
                        <li class="active"><a href="#forgot">Quên mật khẩu</a></li>
                        
                    </ul>
                    <div class="ps-tabs">
                        <div class="ps-tab active" id="forgot">
                            <form method="POST" action="{{route('client.account.post-forgot')}}" class="{{parse_classname('forgot-form')}}" >
                                @if ($next = old('next', $request->next))
                                    <input type="hidden" name="next" value="{{$next}}">
                                @endif
                                @csrf
                            
                                <div class="ps-form__content">
                                    <h5>Đặt lại mật khẩu</h5>
                                    <div class="form-group">
                                        <input class="form-control theme-size" type="email" name="email" placeholder="Nhập Email của bạn">
                                    </div>
                                    @if ($error = session('error'))
                                        <div class="alert alert-danger text-center">
                                            {{$error}}
                                        </div>
                                    @endif
                                    <div class="form-group submtit">
                                        <button class="food-btn bs-size  style-2 w-100p"><span>Gửi yêu cầu</span></button>
                                    </div>
                                </div>
                                
                                <div class="ps-form__footer">
                                    <p>
                                        <a href="{{route('client.account.login')}}">Đăng nhập</a>
                                        | 
                                        <a href="{{route('client.account.register')}}">Đăng ký</a>
                                    </p>
                                    
                                </div>
                            </form>
                        </div>
                        
                    </div>
                </div>
        
            </div>
        </section>
        <!-- buzz soon section ending here -->


@endsection