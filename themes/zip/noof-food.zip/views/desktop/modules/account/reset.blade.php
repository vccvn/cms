@extends($_layout.'master')
@section('title', 'Tạo mật khẩu mới')
@section('page_type', 'my-account')

@section('content')


		<!-- buzz soon section start here -->
        <section class="buzz-section d-flex align-items-center">
            <div class="container">
                <div class="ps-form--account ps-tab-root">
                    <ul class="ps-tab-list">
                        <li class="active"><a href="#forgot">Tạo mật khẩu mới</a></li>
                        
                    </ul>
                    <div class="ps-tabs">
                        <div class="ps-tab active" id="forgot">
                            <form method="POST" action="{{route('client.account.password.reset')}}" class="{{parse_classname('reset-form')}}" >
                                @if ($next = old('next', $request->next))
                                    <input type="hidden" name="next" value="{{$next}}">
                                @endif
                                @csrf
                                <input type="hidden" name="token" value="{{old('token', $token)}}">
                            
                                <div class="ps-form__content">
                                    <h5>Tạo mật khẩu mới</h5>
                                    <div class="form-group">
                                        <input class="form-control theme-size" type="password" name="password" placeholder="Mật khẩu mới">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control theme-size" type="password" name="password_confirmation" placeholder="Nhập lại mật khẩu">
                                    </div>
                                    
                                    @if ($error = $errors->first('password')??session('error'))
                                        <div class="alert alert-danger text-center">
                                            {{$error}}
                                        </div>
                                    @endif
                                    <div class="form-group submtit">
                                        <button class="food-btn bs-size  style-2 w-100p"><span>Tạo mật khẩu</span></button>
                                    </div>
                                </div>
                                
                                <div class="ps-form__footer">
                                    <p>
                                        <a href="{{route('client.account.login')}}">Đăng nhập</a>
                                        | 
                                        <a href="{{route('client.account.register')}}">Đăng ký</a>
                                    </p>
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- buzz soon section ending here -->




@endsection