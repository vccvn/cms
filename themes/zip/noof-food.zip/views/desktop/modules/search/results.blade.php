@extends($_layout.'master')
@section('title', 'Kết quả tìm kiếm cho ['.$keywords.']')
@section('meta.robots', 'noindex')

@section('content')
    



        
        <!-- Page Header Section Start Here -->
        <section class="page-header style-2">
            <div class="container">
                <div class="page-title text-center">
                    <div class="buzz-form mb-4 max-800px mr-auto ml-auto">
                        <form action="{{route('client.search')}}" method="GET">
                            <label class="label-search">
                                <input type="search" name="s" placeholder="Nhập từ khóa..." class="inp-search" value="{{$keywords}}">
                            </label>
                            <input type="submit" name="submit" value="Tìm kiếm">
                        </form>
                    </div>
                    <ul class="breadcrumb">
                        @if (count($refs = $helper->getSearchRefOptions($r = strtolower($request->ref))))
                            
                            @foreach ($refs as $ref => $text)
                            <li class="{{$ref == $r ? 'active': ''}}">
                                @if ($ref == $r)
                                {{$text}}
                                @else
                                <a href="{{route('client.search', ['ref' => $ref, 's' => $keywords])}}">{{$text}}</a>    
                                @endif
                                
                            </li>
                            @endforeach
                            
                        
                        @endif
                    </ul>
                </div>
            </div>
        </section>
        <!-- Page Header Section Ending Here -->

        <!-- Blog Page Section Start Here -->
        <div class="blog-section blog-page padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    
                    <div class="row justify-content-center">
                        @if (count($results))
                            @foreach ($results as $result)
                            
                            <div class="col-lg-4 col-sm-6 col-12">
                                <div class="post-item">
                                    <div class="post-item-inner">
                                        <div class="post-thumb">
                                            <a href="{{$u = $result->getViewUrl()}}"><img src="{{$result->getFeatureImage()}}" alt="{{$result->title}}"></a>
                                        </div>
                                        <div class="post-content">
                                            <h5><a class="" href="{{$u}}">{{$result->sub('title', 64, '...')}}</a></h5>
                                            <div class="author-date">
                                                <a href="{{$u}}" class="date"><i class="icofont-calendar"></i>{{$result->dateFormat('d/m/Y')}}</a>
                                                @if ($result->author)
                                                <a href="#" class="admin"><i class="icofont-ui-user"></i>{{$result->author->name}}</a>    
                                                @endif
                                                
                                            </div>
                                            <p>{{$result->getShortDesc(120)}}</p>
                                            <div class="post-footer">
                                                <a href="{{$u}}" class="text-btn">Chi tiết<i class="icofont-double-right"></i></a>
                                                <a href="{{$u}}#comments" class="comments"><i class="icofont-comment"></i><span>{{$result->comments_count??0}}</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
            
                            <div class="col-12">
                                {{$results->links($_template.'pagination')}}
                            </div>
                        @else
                            <div class="col-12">
                                <div class="alert alert-warning text-center">
                                    Không có kết quả phù hợp
                                </div>
                            </div>
                        @endif
                    </div>
                        
                </div>
            </div>
        </div>
        







@endsection


