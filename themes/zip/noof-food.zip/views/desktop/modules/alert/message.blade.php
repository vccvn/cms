@extends($_layout.'master')
@section('title', 'Thông báo')
@include($_lib.'register-meta')

@section('content')
<?php
    $type = (isset($type) && $type)?$type:(session('type')?session('type'):'success');
    $message = (isset($message) && $message)?$message:(session('message')?session('message'):'Hello World');
    $link = isset($link)?$link:(session('link')?session('link'):route('home'));
    $text = isset($text)?$text:(session('text')?session('text'):'<i class="fa fa-home"></i> Về trang chủ');
    $title = (isset($title) && $title)?$title:(session('title')?session('title'):null);
    
?>

		<!-- buzz soon section start here -->
        <section class="buzz-section d-flex align-items-center">
            <div class="container">
                <div class="ps-section__header mb-4 text-center">
                    <h3>{{$title?$title:'Thông báo'}}</h3>
                </div>
                <div class="row">
                    <div class="col-md-10 col-lg-8 ml-auto mr-auto">
                        <div class="alert alert-{{$type}} text-center">
                            {!! $message !!}
                        </div>
                        <div class="buttons text-center" style="margin: 20px auto;">
                            <a href="{{$link}}" class="theme-btn btn-style-two">{!! $text !!}</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- buzz soon section ending here -->
@endsection