@extends($_layout . 'master')

@include($_lib.'register-meta')

@section('content')
    {!! $html->desktop_home->components !!}
@endsection
