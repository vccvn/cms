@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('desktop_');
    $pageHeader = $shopOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom' && $pageHeader->background){
            $page_header_background = $pageHeader->background;
        }
    }

@endphp
@extends($_layout.'master')

@section('title', $page_title)
@include($_lib.'register-meta')

@section('content')



        <!-- Shop Cart Page Section start here -->		            
	    <div class="shop-cart padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    @if ($cart && $cart->details && count($cart->details))

                        @php
                            $form = $cart->getForm([
                                'className' => 'form-control theme-size'
                            ]);
                            $info = $form->get('billing_name', 'billing_email', 'billing_phone_number', 'billing_region_id', 'billing_district_id', 'billing_ward_id', 'billing_address');
                            $shipping = $form->get('shipping_name', 'shipping_email', 'shipping_phone_number', 'shipping_region_id', 'shipping_district_id', 'shipping_ward_id', 'shipping_address');
                        @endphp
                        <div class="cart-bottom">
                            <form class="shiping-box {{parse_classname('checkout-form', 'place-order-form')}}" action="{{route('client.orders.place-order')}}" method="post">
                                @csrf
                                <div class="row">
                                    <div class="col-md-7 col-12">
                                        <div class="">
                                            <h5>Thanh toán & nhận hàng</h5>
                                    
                                            
                                            <div class="ps-form__billing-info">
                                                @foreach ($info as $input)
                                                    
                                                    <div class="form-group">
                                                        <label for="{{$input->id}}">
                                                            {{$input->label}}
                                                            @if ($input->required)
                                                            <sup>*</sup>
                                                            @endif
                                                        </label>
                                                        <div class="form-group__content">
                                                        {!! $input !!}
                                                        </div>
                                                        @if ($input->error)
                                                            <div class="error has-error">{{$input->error}}</div>
                                                        @endif
                                                    </div>
                                                @endforeach
                                                @if (!$helper->isLogin())
                                                    <div class="account-group {{parse_classname('account-group')}}">
                                                        <div class="form-group">
                                                            <div class="ps-checkbox">
                                                                {!! $create = $form->get('create_account')->addClass(parse_classname('create-account-checkbox') . ' mr-2')->removeClass('form-control') !!}
                                                            </div>
                                                        </div>

                                                        <div class="create-account-group {{parse_classname('create-account-group')}} {{$create->value?'show':''}}">
                                                            <p>Tạo một tài khoản từ thông tin đơn hàng. Lần tới mua hàng bạn có thể dùng tài khoản này để đặt hàng dễ dàng hơn và tiện quản lý</p>
                                                            <div class="form-group">
                                                                <label for="{{($input = $form->password)->id}}">
                                                                    {{$input->label}}
                                                                </label>
                                                                <div class="form-group__content">
                                                                {!! $input !!}
                                                                </div>
                                                                @if ($input->error)
                                                                    <div class="error has-error">{{$input->error}}</div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="shipping-group {{parse_classname('shipping-group')}}">
                                                    <div class="form-group">
                                                        <div class="ps-checkbox">
                                                            {!! $checkbox = $form->get('ship_to_different_address')->addClass(parse_classname('ship-to-different-address') . ' mr-2')->removeClass('form-control') !!}
                                                        </div>
                                                    </div>
                                                    <div class="shipping-address-group {{parse_classname('shipping-address-group')}} {{$checkbox->value?'show':''}}">
                                                        @foreach ($shipping as $input)
                                                    
                                                            <div class="form-group">
                                                                <label for="{{$input->id}}">
                                                                    {{$input->label}}
                                                                    @if ($input->required)
                                                                    <sup>*</sup>
                                                                    @endif
                                                                </label>
                                                                <div class="form-group__content">
                                                                {!! $input !!}
                                                                </div>
                                                                @if ($input->error)
                                                                    <div class="error has-error">{{$input->error}}</div>
                                                                @endif
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>

                                                {{-- <h3 class="mt-40"> Addition information</h3> --}}
                                                <div class="form-group">
                                                    <label for="{{($input = $form->note)->id}}">
                                                        {{$input->label}}
                                                    </label>
                                                    <div class="form-group__content">
                                                    {!! $input !!}
                                                    </div>
                                                </div>
                                                <div class="checkout-payment {{parse_classname('payment-methods')}}">
                                                    @if (count($methods = $helper->getOrderPaymentMethods()))
                                                        <?php 
                                                        $defaultMethod = old('payment_method')??(isset($methods[0])?$methods[0]->value:0);
                                                        ?>
                                                        @foreach ($methods as $method)
                                                            <div class="payment-group {{parse_classname('payment-method-option')}}">
                                                                <div class="form-group">
                                                                    <div class="ps-radio">
                                                                        <input type="radio" class="{{parse_classname('payment-method-value')}}" value="{{$method->value}}" name="payment_method" id="payment-method-{{$method->value}}" @if($method->value == $defaultMethod) checked @endif>
                                                                        <label class="payment-label {{parse_classname('payment-method-label')}}" for="payment-method-{{$method->value}}">{{$method->name}}</label>
                                                                    </div>
                                                                    <div class="{{parse_classname('payment-method-description', 'payment-method-description-'.$method->value)}} {{$method->value == $defaultMethod ? 'show' : ''}}" data-method="{{$method->value}}" id="payment-description-{{$method->value}}">
                                                                        <p>{{$method->description}}</p>
                                                                    </div>
                                                                </div>
                                                                
                                                            </div>
                                                            
                                                        @endforeach
                                                    @endif
                                                </div>
                    
                                                <button type="submit" class="food-btn style-2"><span>Đặt hàng</span></button>
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-5">
                                        <div class="cart-overview">
                                            <h5>Hóa đơn</h5>
                                            <ul>
                                                @foreach ($cart->details as $item)
                                                    <li class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                                        <span class="pull-left max-70">
                                                            <div>{{$item->product_name}}</div>
                                                            @if ($item->attributes && count($item->attributes))
                                                                <div>
                                                                    @foreach ($item->attributes as $attr)
                                                                    <div>{{$attr->label??$attr->name}}: {{$attr->text}}</div>
                                                                    @endforeach
                                                                </div>
                                                            @endif
                                                            <div>Số lượng: {{$item->quantity}}</div>
                                                        </span>
                                                        <p class="pull-right {{parse_classname('item-total-price')}}">{{$item->getTotalFormat()}}</p>
                                                    </li>
                                                @endforeach
                                            </ul>
                                            <hr style="height: 1px ">
                                            <ul>
                                                <li>
                                                    <span class="pull-left">Tạm tính</span>
                                                    <p class="pull-right {{parse_classname('cart-sub-total-ammount')}}">{{$helper->getCurrencyFormat($cart->sub_total)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Phí giao hàng</span>
                                                    <p class="pull-right {{parse_classname('cart-shipping-fee')}}">{{$helper->getCurrencyFormat($cart->shipping_fee)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Thuế VAT</span>
                                                    <p class="pull-right {{parse_classname('cart-tax-ammount')}}">{{$helper->getCurrencyFormat($cart->tax)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Tổng thành tiền</span>
                                                    <p class="pull-right {{parse_classname('cart-total-ammount')}}">{{$helper->getCurrencyFormat($cart->total_money)}}</p>
                                                </li>
                                            </ul>
            
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>


                    @else
                        <div class="text-center">
                            <h3>Không có sản phẩm nào trong giỏ hàng</h3>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <!-- Shop Cart Page Section ending here -->




@endsection