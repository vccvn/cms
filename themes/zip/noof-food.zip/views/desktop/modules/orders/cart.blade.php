@php
    $allow_place_order = $ecommerce->allow_place_order;
    $shopOptions = $options->theme->shop->makeByPrefix('desktop_');
    $pageHeader = $shopOptions->makeByPrefix('page_header_');
    if($pageHeader->show){
        $show_page_header = 1;
        if($pageHeader->background_type == 'custom' && $pageHeader->background){
            $page_header_background = $pageHeader->background;
        }
    }

@endphp
@extends($_layout.'master')
@section('title', 'Giỏ hàng')
@include($_lib.'register-meta')

@section('content')

        <!-- Shop Cart Page Section start here -->		            
	    <div class="shop-cart padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    @if ($cart && $cart->details && count($cart->details))
                    
                        <div class="cart-top">
                            <table>
                                <thead>
                                    <tr>
                                        <th class="w-xl-50p">Thông tin sản phẩm</th>
                                        <th class="text-right">Đơn giá</th>
                                        <th>Số lượng</th>
                                        <th class="text-right">Thành tiền</th>
                                        <th>Xóa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($cart->details as $item)
                                        <tr class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                            <td class="product-item w-xl-50p">
                                                <div class="p-thumb">
                                                    <a href="{{$item->link}}">
                                                        <img src="{{$item->image}}" alt="{{$item->product_name}}">
                                                    </a>
                                                </div>
                                                <div class="p-content">
                                                    <a href="{{$item->link}}">{{$item->product_name}}</a>
                                                    @if ($item->attributes && count($item->attributes))
                                                        @foreach ($item->attributes as $attr)
                                                            <p>{{$attr->label??$attr->name}}: <strong>{{$attr->text}}</strong></p>
                                                        @endforeach
                                                    @endif
                                                </div>
                                            </td>
                                            <td class="price text-right"><strong>{{$item->getPriceFormat()}}</strong></td>
                                            <td>
                                                <div class="cart-plus-minus">
                                                    <div class="dec qtybutton">-</div>
                                                    <input class="cart-plus-minus-box {{parse_classname('product-order-quantity', 'quantity', 'item-quantity')}} inp-quantity" type="text" name="quantity[{{$item->id}}]" id="qty{{$item->id}}" value="{{$item->quantity}}" data-item-id="{{$item->id}}" min="1" placeholder="1">
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </td>
                                            <td class="text-right"><strong class="{{parse_classname('item-total-price')}}">{{$item->getTotalFormat()}}</strong></td>
                                            <td><a href="#" class="{{parse_classname('remove-cart-item')}}" data-item-id="{{$item->id}}"><i class="fa fa-trash"></i></a></td>
                                        </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>
                        <div class="cart-bottom">
                            <div class="cart-checkout-box">
                                <form class="coupon">
                                    <input type="text" name="coupon" placeholder="Coupon Code..." class="cart-page-input-text">
                                    <input type="submit" value="Apply Coupon">
                                </form>
                                <div class="cart-checkout">
                                    <a class="food-btn style-2 w-48p {{parse_classname('btn-update-cart')}}" href="javascript:void('Cập nhật giỏ hàng')">
                                        <span>
                                            <i class="fa fa--sync"></i> Cập nhật giỏ hàng
                                        </span>
                                    </a>
                                    <a class="food-btn style-2 w-48p" href="{{route("client.orders.checkout")}}">
                                        <span>Thanh toán</span>
                                    </a>
                                </div>
                            </div>
                            <div class="shiping-box">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        {{-- <div class="calculate-shiping">
                                            <h4>Calculate Shipping</h4>
                                            <div class="outline-select">
                                                <select>
                                                    <option value="volvo">United Kingdom (UK)</option>
                                                    <option value="saab">Bangladesh</option>
                                                    <option value="saab">Pakisthan</option>
                                                    <option value="saab">India</option>
                                                    <option value="saab">Nepal</option>
                                                </select>
                                                <span class="select-icon"><i class="icofont-caret-down"></i></span>
                                            </div>
                                            <div class="outline-select shipping-select">
                                                <select>
                                                    <option value="volvo">State/Country</option>
                                                    <option value="saab">Dhaka</option>
                                                    <option value="saab">Benkok</option>
                                                    <option value="saab">Kolkata</option>
                                                    <option value="saab">Kapasia</option>
                                                </select>
                                                <span class="select-icon"><i class="icofont-caret-down"></i></span>
                                            </div>
                                            <input type="text" name="coupon" placeholder="Postcode/ZIP" class="cart-page-input-text"/>	
                                            <button type="submit" class="food-btn"><span>Update Total</span></button>
                                        </div> --}}
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="cart-overview">
                                            <h4>Hóa đơn</h4>
                                            <ul>
                                                <li>
                                                    <span class="pull-left">Tạm tính</span>
                                                    <p class="pull-right {{parse_classname('cart-sub-total-ammount')}}">{{$helper->getCurrencyFormat($cart->sub_total)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Phí giao hàng</span>
                                                    <p class="pull-right {{parse_classname('cart-shipping-fee')}}">{{$helper->getCurrencyFormat($cart->shipping_fee)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Thuế VAT</span>
                                                    <p class="pull-right {{parse_classname('cart-tax-ammount')}}">{{$helper->getCurrencyFormat($cart->tax)}}</p>
                                                </li>
                                                <li>
                                                    <span class="pull-left">Tổng thành tiền</span>
                                                    <p class="pull-right {{parse_classname('cart-total-ammount')}}">{{$helper->getCurrencyFormat($cart->total_money)}}</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @else
                        <div class="text-center">
                            <h3>Không có sản phẩm nào trong giỏ hàng</h3>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <!-- Shop Cart Page Section ending here -->
    




@endsection