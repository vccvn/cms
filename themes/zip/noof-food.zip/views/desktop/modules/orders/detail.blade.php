@php
    $show_breadcrumb = true;
@endphp

@extends($_layout.'master')
@include($_lib.'register-meta')

@section('content')




<!-- buzz soon section start here -->
<section class="buzz-section d-flex align-items-center">
    <div class="container">
        @if ($order && $order->details && count($order->details))
            <div class="order-detail">
                <div class="row">
                    <div class="col-lg-4">
                        <figure class="card-box bg-white">
                            <h5>Hóa đơn</h5>
                            <div class="cart-calculator-table table-content table-responsive">
                                <table class="table ps-table ps-table--vendor-status">
                                    <tbody>
                                        <tr class="cart-subtotal">
                                            <td>Mã đơn hàng</td>
                                            <td><span>{{$order->id}}</span></td>
                                        </tr>
                                        <tr class="cart-subtotal">
                                            <td>Trạng thái</td>
                                            <td><span>{{$order->getStatusLabel()}}</span></td>
                                        </tr>
                                        <tr class="cart-subtotal">
                                            <td>Thanh toán</td>
                                            <td><span>{{$order->getPaymentMethodText()}}</span></td>
                                        </tr>
                                        <tr class="cart-subtotal">
                                            <td>Tạm tính</td>
                                            <td><span class="price-ammount">{{get_currency_format($order->sub_total)}}</span></td>
                                        </tr>
                                        <tr class="shipping">
                                            <td>Phí giao hàng</td>
                                            <td><span class="price-ammount">{{get_currency_format($order->shipping_fee)}}</span></td>
                                        </tr>
                                        <tr class="shipping">
                                            <td>Thuế</td>
                                            <td><span class="price-ammount">{{get_currency_format($order->tax)}}</span></td>
                                        </tr>
                                        <tr class="cart-total">
                                            <td>Tổng tiền</td>
                                            <td><span class="price-ammount">{{get_currency_format($order->total_money)}}</span></td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                            @if ($order->isPaymentMethod('transfer') && $order->isStatus('pending-payment') )
                                <a href="{{route('client.payments.check-order', ['order_id' => $order->id, 'contact' => $order->billing->email])}}" class=" food-btn w-100p "><span>Thanh toán</span></a>
                            @endif
                            @if ($order->canCancel())
                            <a href="#" class="{{parse_classname('btn-cancel-order')}} d-block text-center text-danger pt-2 pb-2" data-id="{{$order->id}}">Hủy</a>
                            @endif
                            
                        </figure>

                        <figure class="card-box bg-white">
                            <h5>Giao hàng</h5>
                            <div class="cart-calculator-table table-content table-responsive">
                                <table class="table ps-table ps-table--vendor-status">
                                    <tbody>
                                        <tr>
                                            <td>Họ và tên</td>
                                            <td>{{$order->shipping->name}}</td>
                                        </tr>
                                        <tr>
                                            <td>Số diện thoại</td>
                                            <td>{{$order->shipping->phone_number}}</td>
                                        </tr>
                                        <tr>
                                            <td>Email</td>
                                            <td>{{$order->shipping->email}}</td>
                                        </tr>
                                        <tr>
                                            <td>Địa chỉ giao hàng</td>
                                            <td>{{$order->shipping->getFullAddressText()}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </figure>
                    </div>
                    <div class="col-lg-8 ">
                        <figure class="card-box bg-white">
                            <h5>Chi tiết</h5>
                            <div class="cart-table table-content table-responsive">
                                <table class="table ps-table ps-table--vendor detail-table">
                                    <thead>
                                        <tr>
                                            <th>Ảnh</th>
                                            <th>Sản phẩm</th>
                                            <th>Đơn giá</th>
                                            <th>Số lượng</th>
                                            <th>Thành tiền</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($order->details as $item)
                                            <tr class="{{parse_classname('cart-item', 'cart-item-'.$item->id)}}" id="cart-item-{{$item->id}}">
                                                <td class="image-column">
                                                    <a href="{{$item->link}}">
                                                        <img src="{{$item->image}}" alt="{{$item->product_name}}">
                                                    </a>
                                                </td>
                                                <td class="wide-column">
                                                    <a href="{{$item->link}}">{{$item->product_name}}</a>
                                                    @if ($item->attributes && count($item->attributes))
                                                        @foreach ($item->attributes as $attr)
                                                            <p>{{$attr->label??$attr->name}}: {{$attr->text}}</p>
                                                        @endforeach
                                                    @endif
                                                </td>
                                                <td class="product-price"><strong>{{$item->getPriceFormat()}}</strong></td>
                                                <td class="product-quantity">
                                                    <div class="quantity">
                                                        {{$item->quantity}}
                                                    </div>
                                                </td>
                                                <td class="product-price"><strong class="{{parse_classname('item-total-price')}}">{{$item->getTotalFormat()}}</strong></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </figure><!-- Cart Area End --> 
                    </div>
                </div>
            </div>
        @else
            <div class="alert alert-warning text-center">
                Không có sản phẩm nào trong giỏ hàng
            </div>
        @endif

    </div>
</section>
<!-- buzz soon section ending here -->

@endsection

@section('css')
    <style>
        h5{
            margin-bottom: 15px;
        }
    </style>
@endsection