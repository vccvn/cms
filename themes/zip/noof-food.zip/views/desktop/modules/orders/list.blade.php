@php
    $show_breadcrumb = true;
@endphp
@extends($_layout.'master')
@include($_lib.'register-meta')

@section('content')




<!-- buzz soon section start here -->
<section class="buzz-section d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mb-md-5 pb-50">

                <div class="widget card-box">
                    <a class="nav-link {{$key?'': 'active'}}" href="{{route('client.orders.manager')}}">Tất cả đơn hàng</a>
                    @foreach ($status_list as $item)
                        <a class="nav-link {{$key == $item->key ? "active":""}}" href="{{route('client.orders.list', ['status_key' => $status_keys[$item->key]])}}">{{$item['label']}}</a>
                    @endforeach
                    <a class="nav-link" href="{{route('client.customers.logout')}}">Thoát</a>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="card-box bg-white p-4">
                    <h5 class="mb-2">{{$list_title}}</h5>
                    @if (count($orders))
                    <div class="">
                        <table class="table ps-table ps-table--vendor">
                            <thead>
                                <tr>
                                    <th>Mã</th>
                                    <th>Thời gian</th>
                                    <th>Phương thức thanh toán</th>
                                    <th>Trạng thái</th>
                                    <th>Giá trị</th>
                                    <th>Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($orders as $order)
                                    <tr class="{{parse_classname('order-item', 'order-item-'.$order->id)}}" id="{{'order-item-'.$order->id}}">
                                        <td>{{$order->id}}</td>
                                        <td>{{$order->dateFormat('d/m/Y')}}</td>
                                        <td class="wide-column">{{isset($payment_methods[$order->payment_method])?$payment_methods[$order->payment_method]['name']:"Không xác định"}}</td>
                                        <td>{{$order->getStatusLabel()}}</td>
                                        <td>{{$helper->getCurrencyFormat($order->total_money)}}</td>
                                        <td>
                                            <a href="{{route('client.orders.detail', ['id' => $order->id])}}" class="">Chi tiết</a>
                                            @if ($order->canCancel())
                                            |
                                            <a href="#" class="{{parse_classname('btn-cancel-order')}}" data-id="{{$order->id}}">Hủy</a>
                                            @endif
                                        </td>
                                    </tr>
                                        
                                @endforeach
                            </tbody>
                        </table>

                        {{$orders->links($_template.'pagination')}}
                    </div>
                    @else
                        <div class="alert alert-warning text-center">
                            Không có đơn hàng nào!
                        </div>
                    @endif

                </div>

            </div>
        </div>
    </div>
</section>
<!-- buzz soon section ending here -->

@endsection