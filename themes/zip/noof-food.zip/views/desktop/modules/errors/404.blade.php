@extends($_layout.'master')
@section('meta.robots', 'noindex')
@section('title', '404 - Không tìm thấy')
@section('content')




		<!-- buzz soon section start here -->
        <section class="buzz-section d-flex align-items-center">
            <div class="container">
                <div class="row flex-row-reverse align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="buzz-thumb">
                            <img src="{{desktop_asset('images/404.png')}}" alt="404_image">
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="buzz-area">
                            <div class="section-header">
                                <h3>Ôi! Trang này không có</h3>
                                <p>Trang bạn đang truy cập hiện không có hoặc đã bị xóa! Hãy dên<a href="{{route('home')}}"> Trang chủ</a> để tìm kiếm sự giúp đỡ</p>
                            </div>
                            <div class="section-wrapper">
                                <div class="news-letter">
                                    <div class="section-wrapper">
                                        <div class="news-form">
                                            <form action="{{route('client.products')}}" method="GET">
                                                <label class="label-search">
                                                    <input type="search" name="s" placeholder="Nhập từ khóa..." class="inp-search">
                                                </label>
                                                <input type="submit" name="submit" value="Tìm kiếm">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- buzz soon section ending here -->

@endsection